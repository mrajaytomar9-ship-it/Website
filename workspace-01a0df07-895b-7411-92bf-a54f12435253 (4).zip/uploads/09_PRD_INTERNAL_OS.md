```yaml
document_id: NXT-PROD-001
title: Nextera Internal Operating System — Product Requirements
version: 0.1.0
document_status: DRAFT
owner_role: FOUNDER
approval_status: PENDING
approved_by: null
approval_reference: null
effective_date: null
last_updated: SET_WHEN_SAVED
information_classification: INTERNAL
canonical_location: TO_BE_ASSIGNED
related_documents:
  - NXT-GOV-000
  - NXT-GOV-003
  - NXT-GOV-004
  - NXT-BIZ-001
  - NXT-BIZ-003
  - NXT-BIZ-004
```

## 1. Product summary

The Nextera Internal Operating System is the coordinated working environment used to manage:

- Leads.
- Sales.
- Clients.
- Projects.
- Tasks.
- Approvals.
- Invoice/payment references.
- Support.
- Recurring delivery.
- Evidence and reporting.

It may initially consist of connected tools and manual procedures rather than a custom application.

### Product distinction

```text
Nextera Solution:
The business.

Internal Operating System:
The business's working records, interfaces and coordination workflows.

Munder Difflin:
Preferred candidate for the virtual-office interface.

Nextera OS:
Potential future customer-facing product, outside this PRD.
```

---

## 2. Product objective

Enable routine work to progress with clear ownership, reliable context and visible exceptions.

The founder should be able to answer:

1. What needs my decision?
2. Which client commitments are at risk?
3. What was actually completed?
4. What is blocked?
5. Which payments require verification?
6. What should happen next?

The product must not merely display agent activity.

A busy virtual office without reliable records does not satisfy this PRD.

---

## 3. Product principles

### PROD-P01 — Records before animation

Operational correctness takes priority over visual simulation.

### PROD-P02 — Tool-independent business logic

Company states and permissions must not depend entirely on a particular interface.

### PROD-P03 — Human control without constant interruption

Escalate meaningful exceptions, not every internal draft.

### PROD-P04 — Evidence-backed completion

Actions require observable completion criteria.

### PROD-P05 — Manual fallback

Unavailable integrations must produce a clear manual task.

### PROD-P06 — Progressive autonomy

Autonomy expands per workflow after testing, not globally.

### PROD-P07 — Client isolation

Every client-specific action must identify its client context.

---

## 4. Users and roles

| Role | Primary needs | Initial authority |
|---|---|---|
| Founder/admin | Priorities, approvals, cash, quality | Accountable decision-maker |
| Operations assistant | Routing and record maintenance | Bounded internal operations |
| Research/sales assistant | Lead facts and approved offers | Research/drafts |
| Delivery assistant | Scope, assets and tasks | Authorized staging work |
| Client-success assistant | Requests and approved knowledge | Drafts/bounded routine replies |
| QA/reporting assistant | Test criteria and evidence | Review and reporting |
| Future contractor | Assigned project context | Explicit limited access |

Clients are not initial internal-system users.

Client portals are outside MVP scope.

---

## 5. Release phases

### R0 — Manual operational baseline

- Canonical records.
- Templates.
- Founder-operated approvals.
- Manual invoice and messaging handoffs.
- One complete test-client workflow.

### R1 — Assisted operations

- Agents read authorized context.
- Generate drafts.
- Suggest tasks.
- Prepare founder briefings.
- No unsupported external execution.

### R2 — Supervised integrations

- Approved API/tool connections.
- Execution of specifically approved actions.
- Logs, retry limits and duplicate protection.

### R3 — Bounded autonomy

- Selected low-risk recurring actions.
- Explicit limits.
- Tested escalation and recovery.
- Monitoring appropriate to the service promise.

No release date is committed by this PRD.

---

## 6. Information architecture

### Core entities

```text
Lead
Client
Contact
Opportunity
Scope/Agreement
Project
Task
Approval
Invoice Reference
Receipt Reference
Support Ticket
Incident
Recurring Service Plan
Artifact
Evidence
Decision
Activity Event
```

### Relationship rules

- One client may have multiple projects.
- A project references one governing scope version.
- A task belongs to a project, client operation or internal objective.
- An approval references an exact action/payload.
- A receipt can be allocated to one or more invoices through explicit records.
- Evidence references the event or test it supports.
- Agent memory is not the canonical client database.

Detailed field definitions belong in the upcoming data dictionary.

---

## 7. Module A — Founder command center

### Required views

1. Today’s priorities.
2. Pending approvals.
3. Client commitments at risk.
4. Missing client inputs.
5. Failed/blocked agent tasks.
6. Payment-verification queue.
7. Support incidents.
8. Upcoming recurring work.

### PRD-001 — Actionable dashboard

**Priority:** MUST  
**Release:** R0

Each displayed item must link to the underlying record and next action.

**Acceptance:** The founder can open the source record from every actionable dashboard item.

### PRD-002 — Honest status presentation

**Priority:** MUST  
**Release:** R0

Distinguish:

```text
Drafted
Awaiting input
Awaiting approval
Executed
Verified
Failed
```

**Acceptance:** A generated draft never appears as a completed external action.

### PRD-003 — Founder briefing

**Priority:** SHOULD  
**Release:** R1

Briefing includes:

- Completed work with references.
- Decisions needed.
- Blockers.
- Risks.
- Next priorities.

It must not invent progress to fill a reporting template.

---

## 8. Module B — Lead and sales workspace

### PRD-004 — Lead capture

Store business identity, source, niche, fit observations, contact route and opt-out state.

**Priority:** MUST  
**Release:** R0

### PRD-005 — Next-action tracking

Every active opportunity has an owner and next action.

**Priority:** MUST  
**Release:** R0

### PRD-006 — Proposal preparation

Draft proposals from approved commercial inputs.

**Priority:** MUST  
**Release:** R1

Missing price approval produces `NEEDS_APPROVAL`, not a guessed price.

### PRD-007 — Outreach boundary

External sending requires the applicable approved recipient, content and channel.

**Priority:** MUST  
**Release:** R2

Opted-out contacts must be excluded from applicable outreach queues.

### Acceptance

A lead can progress from research to accepted scope without losing source evidence, commercial approvals or next actions.

---

## 9. Module C — Client onboarding

### PRD-008 — Onboarding checklist

Track:

- Authorized representative.
- Scope.
- Payment condition.
- Required assets.
- Business facts.
- Access requirements.
- Approval owner.
- Missing dependencies.

**Priority:** MUST  
**Release:** R0

### PRD-009 — Readiness gate

Delivery readiness must be derived from required conditions, not an arbitrary agent statement.

**Priority:** MUST  
**Release:** R0

### PRD-010 — Credential separation

Store access references, not raw secrets in general project fields.

**Priority:** MUST  
**Release:** R0

### Acceptance

The founder can see exactly what prevents a project from starting and who must supply it.

---

## 10. Module D — Project and delivery workspace

### PRD-011 — Scope-linked task creation

Tasks reference the governing scope and acceptance criteria.

**Priority:** MUST  
**Release:** R0

### PRD-012 — Artifact versioning

Identify the draft/build version reviewed by the client or QA.

**Priority:** MUST  
**Release:** R0

### PRD-013 — Change requests

New out-of-scope requests create a change record.

**Priority:** MUST  
**Release:** R0

### PRD-014 — QA gate

Critical failed or unperformed required tests block release.

**Priority:** MUST  
**Release:** R0

### PRD-015 — Production approval

Publishing requires approval for the relevant artifact and target.

**Priority:** MUST  
**Release:** R2 for integrated publishing; manual equivalent in R0.

### Acceptance

A project cannot appear as verified live solely because a build file exists or a deployment command returned success.

---

## 11. Module E — Finance references

The internal OS is not initially a full accounting platform.

### PRD-016 — Invoice linkage

Store invoice identifiers, status and source references.

**Priority:** MUST  
**Release:** R0

### PRD-017 — Payment verification

Payment status requires supporting receipt evidence.

**Priority:** MUST  
**Release:** R0

### PRD-018 — Financial action boundary

Spending, refunds and financial adjustments require founder authorization.

**Priority:** MUST  
**Release:** R0/R2 as applicable.

### PRD-019 — Reconciliation exceptions

Flag:

- Unallocated receipts.
- Duplicates.
- Amount mismatches.
- Overdue balances.
- Missing evidence.

**Priority:** SHOULD  
**Release:** R1

### Acceptance

The interface clearly distinguishes invoiced, collected and outstanding amounts.

---

## 12. Module F — Support and retention

### PRD-020 — Request intake

A request becomes a traceable ticket.

**Priority:** MUST  
**Release:** R0

### PRD-021 — Scope classification

Classify as:

```text
Included
Possible defect
Change request
Sensitive/escalation required
Unknown
```

**Priority:** MUST  
**Release:** R1

### PRD-022 — Recurring task schedule

Generate or manually schedule contracted monthly work.

**Priority:** MUST  
**Release:** R0 manual; later integrated.

### PRD-023 — Report preparation

Reports use dated records and disclose missing data.

**Priority:** SHOULD  
**Release:** R1

### PRD-024 — Offboarding

Track final obligations, asset transfer, access changes and data handling.

**Priority:** MUST  
**Release:** R0

### Acceptance

A monthly plan produces defined work, not merely an invoice.

---

## 13. Module G — Agent task coordination

### PRD-025 — Structured task assignment

Use the task packet from `NXT-GOV-004`.

**Priority:** MUST  
**Release:** R1

### PRD-026 — Permission-aware execution

Workers receive only necessary tools and client context.

**Priority:** MUST  
**Release:** R2

### PRD-027 — Bounded retries

Every automated tool task has configured limits.

**Priority:** MUST  
**Release:** R2

### PRD-028 — Duplicate-action prevention

Retries must not create duplicate invoices, messages or deployments.

**Priority:** MUST  
**Release:** R2

### PRD-029 — Stop and revoke

The founder can stop new agent actions and revoke access.

**Priority:** MUST  
**Release:** R2

### PRD-030 — Durable handoff

Agent interruption leaves recoverable state.

**Priority:** MUST  
**Release:** R1

### Implementation boundary

A visual mailbox or task animation is insufficient evidence that these capabilities exist. Verify the actual tool behavior.

---

## 14. State models

### Lead/opportunity

```text
RESEARCHED
→ QUALIFICATION_PENDING
→ QUALIFIED
→ CONTACT_PREPARATION
→ CONTACTED
→ DISCOVERY
→ PROPOSAL
→ WON / LOST / NURTURE
```

Opt-out is a separate control, not merely a pipeline stage.

### Project

```text
AWAITING_COMMERCIAL_CONDITIONS
→ ONBOARDING
→ READY
→ IN_BUILD
→ INTERNAL_QA
→ CLIENT_REVIEW
→ AWAITING_RELEASE_CONDITIONS
→ RELEASE_APPROVED
→ LAUNCHED_UNVERIFIED
→ LIVE_VERIFIED
→ HANDOVER_COMPLETE
```

Projects may enter `BLOCKED` or `PAUSED` with a reason.

### Task

```text
QUEUED
READY
IN_PROGRESS
NEEDS_INPUT
NEEDS_DECISION
NEEDS_APPROVAL
EXECUTED_UNVERIFIED
VERIFIED
FAILED
CANCELLED
```

A drafting task can be verified as a draft deliverable. This does not imply external execution.

### State-change record

```yaml
record_id:
previous_state:
new_state:
actor:
timestamp:
reason:
evidence_reference:
approval_reference: null
```

---

## 15. Approval experience

Every approval request must show:

- Requested action.
- Client/project.
- Exact artifact or payload.
- Expected external effect.
- Cost, if any.
- Preconditions.
- Risks.
- Recovery option.
- Expiry or validity conditions.

Founder options:

```text
Approve
Reject
Request changes
Defer
```

### Required behavior

- Material payload changes require renewed authorization.
- Approval cannot be reused for another client.
- An agent cannot approve its own restricted action.
- Approval identity must be trustworthy.
- An editable “approved” text field alone is not sufficient enforcement for automated high-impact actions.

If the initial tool cannot enforce these controls, keep the action manual.

---

## 16. Non-functional requirements

### Security

- Least-privilege access.
- Client separation.
- Secure credential storage.
- Appropriate logging and redaction.
- MFA where available.

### Reliability

- Failures visible.
- Retries bounded.
- Records recoverable.
- Duplicate external actions prevented where integrated.
- No silent loss of queued work.

### Usability

- Founder can identify next action without reading full chat histories.
- Technical instructions include verification and recovery.
- Dashboards avoid unnecessary clutter.

### Performance

Initial tasks should remain practical on available hardware.

Specific concurrency, latency and throughput targets require benchmarks.

Do not claim the laptop supports a particular agent count without testing.

### Availability

No 24/7 operation is promised.

Desktop execution may stop when the laptop sleeps, disconnects or shuts down. Persistent service commitments require suitable hosting and monitoring.

### Portability

Core records and approved documents should be exportable in usable formats.

### Privacy

Confidential founder information must not appear in routine client-task context.

---

## 17. Integration requirements

Each integration requires a capability record:

```yaml
integration_id:
provider:
purpose:
supported_actions:
verified_documentation_reference:
authorized_account:
permission_scope:
data_transmitted:
cost_and_limits:
test_environment:
failure_behavior:
duplicate_protection:
disable_procedure:
production_approval_reference:
```

### Initial candidates

| Candidate | Intended role | Current state |
|---|---|---|
| Notion | Operational records | Existing workspace, unreviewed |
| Munder Difflin | Virtual office/coordination | Installed, unconfigured |
| Zoho Invoice | Invoice source | Intended |
| OpenRouter | Model access | Reported access, suitability unverified |
| Hosting provider | Website delivery | Unselected |
| WhatsApp Business | Initial communication | Setup unconfirmed |

A provider’s presence in this table is not an integration commitment.

---

## 18. Build and migration sequence

### Step 1 — Inspect existing workspace

Inventory current Notion pages/databases before creating replacements.

### Step 2 — Select canonical locations

Assign one authoritative location per record type.

### Step 3 — Build minimal records

Leads, clients, projects, tasks, approvals and finance references.

### Step 4 — Run manually

Complete a synthetic test client journey.

### Step 5 — Add read-only/drafting agents

Verify context retrieval and output contracts.

### Step 6 — Add one supervised integration

Prefer a reversible, low-risk use case.

### Step 7 — Test failure paths

Include duplicate retries, missing approvals, wrong client context and interruption.

### Step 8 — Expand only from evidence

Do not configure every agent and integration simultaneously.

### Migration safety

- Export/backup before structural changes.
- Test with nonproduction records.
- Preserve stable IDs.
- Keep mappings for renamed fields.
- Verify record counts and relationships.

---

## 19. Product acceptance scenarios

### UAT-01 — Complete test client

One test client moves from qualification to handover with linked scope, payment evidence, tasks, QA and approvals.

### UAT-02 — Missing approval

A publish request without valid approval does not execute.

### UAT-03 — Duplicate retry

Retrying a completed send/invoice action does not repeat its external effect.

### UAT-04 — Agent outage

Interrupted work remains identifiable and recoverable.

### UAT-05 — Wrong-client context

A task referencing inconsistent client records is blocked or escalated.

### UAT-06 — Payment mismatch

An invoice/receipt discrepancy appears in the exception queue.

### UAT-07 — Scope expansion

A request for a new feature becomes a change request.

### UAT-08 — Unavailable integration

The system produces a manual handoff and does not claim success.

### UAT-09 — Opt-out

An opted-out contact is excluded from applicable outreach actions.

### UAT-10 — Recurring cycle

One monthly service cycle produces tasks, evidence and a report.

### UAT-11 — Founder stop

New automated external actions stop when the authorized control is activated.

### UAT-12 — Restore

A sample backup restores usable records and relationships.

---

## 20. Product success metrics

Track:

- Records missing next actions.
- Overdue client tasks.
- Time waiting for founder approval.
- Human intervention time.
- Verified task-completion rate.
- Unsupported completion reports.
- Duplicate-action incidents.
- Wrong-client-context incidents.
- QA defects.
- Failed integration recovery time.
- Cost per completed workflow.

Do not use agent count, token volume or animated activity as success metrics.

Numerical targets will be set after initial measurements.

---

## 21. Traceability to business requirements

| PRD area | BRD requirements |
|---|---|
| Lead/sales workspace | BR-001–010 |
| Onboarding | BR-011, BR-013 |
| Delivery and release | BR-012–017 |
| Finance references | BR-009–010, BR-028 |
| Support/retention | BR-018–022 |
| Context/task records | BR-023–024 |
| Agent controls | BR-025–026, BR-030 |
| Capacity visibility | BR-027 |
| Security/privacy | BR-029 |

Future TRD choices must explain how they satisfy these requirements.

---

## 22. MVP exclusions

The first internal release does not require:

- Custom client portal.
- Custom accounting software.
- Native mobile application.
- Proprietary model hosting.
- Autonomous sales closing.
- Integrated voice calling.
- Every tool connected by API.
- Continuous parallel agents.
- Advanced predictive dashboards.
- Full multi-tenant SaaS.

A manually operated but reliable workflow is preferable to a falsely autonomous one.

---

## 23. Launch gates

### R0 ready

- Canonical records assigned.
- Manual workflow passes UAT-01.
- Restricted actions remain founder-controlled.
- Data export/recovery method established.
- Scope, evidence and payments remain traceable.

### R1 ready

- Agents receive correct context.
- Outputs follow schemas.
- Missing input/approval is escalated.
- No external execution is falsely reported.

### R2 ready

- Integration permissions verified.
- Restricted actions enforced.
- Duplicate protection and stop controls tested.
- Logs and manual fallback work.

### R3 ready

- Specific workflow demonstrates reliable repeated operation.
- Costs and failure rates are measured.
- Exception coverage is adequate.
- Founder approves the bounded autonomy scope.

---

## 24. Acceptance criteria

- [ ] Product supports the complete client lifecycle.
- [ ] Founder decisions are visible and actionable.
- [ ] Tool capabilities remain unassumed until verified.
- [ ] Record ownership is clear.
- [ ] Draft, execution and verification states are separate.
- [ ] Financial evidence is linked, not invented.
- [ ] Client data remains separated.
- [ ] Agent actions have limits and recovery.
- [ ] Manual fallback is part of the product.
- [ ] Release gates depend on tests rather than appearance.

### Current state

**Detailed PRD drafted. No internal OS modules, dashboards, permissions, integrations or autonomous workflows have been built or verified through this document.**

### Change history

| Version | Change |
|---|---|
| 0.1.0 | Initial internal operating system product specification |

---
