```yaml
document_id: NXT-OPS-003
title: Quality Assurance and Production Release Standard
version: 0.1.0
document_status: DRAFT
owner_role: FOUNDER
approval_status: PENDING
approved_by: null
approval_reference: null
effective_date: null
last_updated: SET_WHEN_SAVED
information_classification: INTERNAL
canonical_location: TO_BE_ASSIGNED
related_documents:
  - NXT-GOV-003
  - NXT-GOV-005
  - NXT-BIZ-003
  - NXT-TECH-001
  - NXT-TECH-002
  - NXT-OPS-002
```

## 1. Purpose

This standard defines how Nextera determines whether a deliverable is:

- Ready for client review.
- Ready for production.
- Successfully launched.
- In need of correction or recovery.

It must prevent:

- Releasing untested work.
- Treating model confidence as evidence.
- Testing one version and publishing another.
- Exposing client information.
- Breaking existing services through careless changes.
- Hiding uncertainty after deployment.

---

## 2. Scope

Applies to:

- Company and client websites.
- Enquiry forms.
- WhatsApp click-to-chat paths.
- Routine GBP corrections.
- Related production configuration.

It is not a full penetration-testing standard, accessibility certification or guarantee of regulatory compliance.

Advanced integrations require additional service-specific tests.

---

## 3. Quality principles

### QA-001 — Test the actual artifact

Checks must identify the artifact version and environment.

### QA-002 — Separate test types

Distinguish:

- Static review.
- Automated checks.
- Manual browser tests.
- External outcome verification.
- Client factual approval.

### QA-003 — No invented pass

A test not performed is `NOT_RUN`.

### QA-004 — Risk-based release

Critical and high-impact defects cannot be hidden behind a high overall score.

### QA-005 — Approval and verification are different

Founder approval allows a release. Verification establishes whether it worked.

### QA-006 — Testing must not harm users

Do not create real bookings, payments, messages or destructive changes merely to test a website without specific authorization.

---

## 4. Responsibilities

| Responsibility | Owner |
|---|---|
| Prepare testable artifact | Delivery role |
| Execute permitted checks | QA role/founder |
| Verify factual claims | Authorized client, with Nextera review |
| Classify release blockers | QA proposes; founder accountable |
| Approve production release | Founder |
| Execute deployment | Authorized operator |
| Verify production | Authorized QA/operator |
| Approve recovery action | Founder or explicit incident policy |

When one person performs several roles, use separate steps and records rather than pretending independent review occurred.

---

## 5. Test outcomes

```text
PASS
FAIL
NOT_RUN
NOT_APPLICABLE
```

### Rules

- `PASS`: acceptance condition observed.
- `FAIL`: acceptance condition not met.
- `NOT_RUN`: test not performed or could not complete.
- `NOT_APPLICABLE`: genuinely irrelevant to scope, with reason.

Do not mark an inconvenient test `NOT_APPLICABLE`.

---

## 6. Defect severity

| Severity | Description | Release treatment |
|---|---|---|
| S1 — Critical | Data exposure, credential leak, unauthorized action, serious safety/security issue | Block; contain and escalate |
| S2 — High | Broken primary enquiry path, wrong contact destination, major business misinformation, key functionality unusable | Block until resolved |
| S3 — Moderate | Secondary function/content issue with limited impact | Resolve or explicitly accept within authority |
| S4 — Minor | Cosmetic issue not materially affecting use | Track; may release with appropriate acknowledgment |

Severity depends on impact, not how easy the issue is to fix.

### Waiver boundaries

- Legal, security or unauthorized-data issues cannot be casually waived.
- A client cannot authorize false professional credentials through a QA exception.
- Cosmetic exceptions must identify the exact issue and planned treatment.
- Unknown critical functionality is not equivalent to low risk.

---

## 7. Test record

```yaml
test_result_id:
project_id:
artifact_id:
artifact_version:
test_id:
environment:
device_or_browser:
performed_by:
performed_at:
outcome:
observations:
evidence_ids: []
limitations: []
defect_id: null
```

### Evidence standards

Useful evidence may include:

- Browser observation.
- Screenshot.
- Provider receipt.
- Test submission.
- Console output.
- Automated report.
- Authorized client confirmation.

A screenshot of a form alone does not prove the submission reaches its destination.

---

## 8. Test matrix

### Group A — Scope and content

| Test ID | Check | Pass condition |
|---|---|---|
| QA-C01 | Scope coverage | Required pages/sections/features exist |
| QA-C02 | Business identity | Approved name/address/contact match |
| QA-C03 | Factual claims | Material claims have approval/evidence |
| QA-C04 | Placeholder removal | No unresolved required placeholders |
| QA-C05 | Asset rights | Published assets have acceptable usage basis |
| QA-C06 | Copy quality | No materially misleading, broken or irrelevant text |
| QA-C07 | Demo identification | Concept work is not presented as real client work |
| QA-C08 | Policies/contact details | Required project-specific information is included |

### Group B — Layout and usability

| Test ID | Check | Pass condition |
|---|---|---|
| QA-U01 | Mobile layout | Core content usable without unintended horizontal scrolling |
| QA-U02 | Desktop layout | Main content and actions render correctly |
| QA-U03 | Navigation | Links lead to intended sections/pages |
| QA-U04 | Text readability | Font size, spacing and contrast support use |
| QA-U05 | Keyboard navigation | Core controls reachable and operable |
| QA-U06 | Focus visibility | Keyboard focus can be identified |
| QA-U07 | Form labels | Inputs have understandable associated labels |
| QA-U08 | Images | Informative images have suitable text alternatives |
| QA-U09 | Error messages | User can understand and correct form errors |
| QA-U10 | Motion | Nonessential motion does not obstruct use |

Passing these checks is not a claim of complete accessibility compliance.

### Group C — Enquiry functionality

| Test ID | Check | Pass condition |
|---|---|---|
| QA-E01 | Phone link | Opens intended phone action |
| QA-E02 | Email link | Uses correct authorized address |
| QA-E03 | WhatsApp number | Correct authorized destination |
| QA-E04 | WhatsApp message | Appropriate encoding and no unnecessary sensitive data |
| QA-E05 | Form validation | Required/invalid fields behave as specified |
| QA-E06 | Successful submission | Intended recipient/system receives labelled test |
| QA-E07 | Failure handling | Failure is not presented as success |
| QA-E08 | Duplicate submission | Behavior is understood and reasonable |
| QA-E09 | Confirmation text | Does not falsely confirm booking/appointment |
| QA-E10 | Spam controls | Suitable controls exist where applicable |

Testing must not send unsolicited messages to third parties.

### Group D — Technical hygiene

| Test ID | Check | Pass condition |
|---|---|---|
| QA-T01 | HTTPS | Intended production site loads securely |
| QA-T02 | Mixed content | No material insecure-resource issue |
| QA-T03 | Broken resources | Required images/scripts/styles load |
| QA-T04 | Browser errors | No unresolved errors impairing key functions |
| QA-T05 | Responsive images | Image sizes are appropriate for delivery |
| QA-T06 | Page metadata | Relevant titles/descriptions exist |
| QA-T07 | Indexing | Staging and production settings match intent |
| QA-T08 | Redirects | Required redirects work without harmful loops |
| QA-T09 | Error page | Invalid path has appropriate behavior |
| QA-T10 | Source recovery | Deployed source/version is recoverable |

Performance scores should be recorded with conditions. They are not ranking guarantees.

### Group E — Privacy and access

| Test ID | Check | Pass condition |
|---|---|---|
| QA-S01 | Secret exposure | No known secrets in client-delivered files or public repository |
| QA-S02 | Form minimization | Fields collect only necessary data |
| QA-S03 | Access | Only authorized accounts have required permissions |
| QA-S04 | Provider handling | Data destinations are understood and authorized |
| QA-S05 | Staging exposure | Access/indexing controls match data sensitivity |
| QA-S06 | Public logs/files | No unnecessary personal or confidential data exposed |
| QA-S07 | Tracking | Applicable notice/consent requirements reviewed before activation |

Automated secret scanning can help but does not prove no secret exists.

---

## 9. Niche-specific checks

### Hotels

| Test ID | Check |
|---|---|
| QA-H01 | Room descriptions match approved information |
| QA-H02 | Images are not misrepresented as actual rooms/facilities |
| QA-H03 | Prices, if shown, have approved conditions and currency |
| QA-H04 | Enquiry is not represented as confirmed reservation |
| QA-H05 | Availability claims require an appropriate verified source |
| QA-H06 | Cancellation/refund information is approved if displayed |

### Clinics

| Test ID | Check |
|---|---|
| QA-M01 | Practitioner names and credentials are approved and not invented |
| QA-M02 | No unsupported treatment or outcome claims |
| QA-M03 | Appointment request is not falsely confirmed |
| QA-M04 | No unnecessary health-record or symptom collection |
| QA-M05 | Administrative content does not become personalized medical advice |
| QA-M06 | Contact/routing information is accurate |

Unknown credentials or medical claims block their publication.

---

## 10. GBP quality checks

| Test ID | Check | Pass condition |
|---|---|---|
| QA-G01 | Correct profile | Work targets the authorized business |
| QA-G02 | Baseline capture | Relevant pre-change values recorded |
| QA-G03 | Approved changes | Desired values authorized and factual |
| QA-G04 | Policy suitability | No knowingly prohibited profile manipulation |
| QA-G05 | Submission result | Actual provider state recorded |
| QA-G06 | Published result | Visible state checked where available |
| QA-G07 | Pending/rejected items | Not misreported as completed |

Do not delete/recreate a profile as a casual recovery action.

---

## 11. Device and browser plan

### Proposed initial minimum

Where available:

- One current Chromium-based desktop browser.
- A narrow mobile viewport.
- A real mobile-device check when available.
- Additional browser checks for functionality that may differ.

### Limitations

- Browser resizing is not identical to real-device testing.
- Do not report Safari/iOS testing if no suitable environment was used.
- If a required target cannot be tested, disclose the limitation and resolve the release impact.

Exact supported-browser commitments belong in the client scope.

---

## 12. Safe test-data policy

Use synthetic, clearly labelled test data.

Example:

```text
Name: Nextera QA Test
Message: Authorized website form test. No customer action required.
```

### Rules

- Use a controlled or client-authorized recipient.
- Coordinate tests that may notify staff.
- Do not use real patient details.
- Do not submit fake reviews.
- Do not make real payments or reservations without separate test authorization.
- Use sandbox modes where available and appropriate.
- Do not delete test data without applicable authority.

If safe production testing is impossible, agree on an alternative verification method and disclose what remains unverified.

---

## 13. Pre-release gate

A release may proceed only when:

- [ ] Exact artifact/version identified.
- [ ] Required tests passed.
- [ ] No unresolved S1 or S2 defect.
- [ ] Remaining issues documented.
- [ ] Client factual approval recorded.
- [ ] Commercial conditions satisfied.
- [ ] Correct production target confirmed.
- [ ] Existing-service impact assessed.
- [ ] Backup/recoverable source available.
- [ ] Deployment and recovery steps prepared.
- [ ] Founder authorization recorded.

### Existing website caution

Before replacing an existing site, inspect dependencies such as:

- Email-related DNS.
- Existing forms.
- Redirects.
- Analytics.
- Business verification records.
- Third-party integrations.

Do not change unrelated DNS records as part of a website launch.

---

## 14. Release manifest

```yaml
release_id:
project_id:
artifact_id:
artifact_version:
source_commit_or_reference:
production_target:
scope_reference:

required_test_result_ids: []
client_approval_reference:
commercial_readiness_reference:
founder_release_approval_id:

changes: []
known_nonblocking_issues: []
expected_external_effects: []

backup_reference:
deployment_steps_reference:
verification_plan_reference:
recovery_plan_reference:

status: PREPARED
```

A release approval applies to this manifest—not every future version.

---

## 15. Deployment procedure

### Before execution

1. Recheck approval applicability.
2. Confirm the target account/domain.
3. Confirm artifact version.
4. Confirm no material change since QA.
5. Verify backup/recovery access.
6. Notify the client if required by the plan.

### During execution

- Follow the approved runbook.
- Record actual actions.
- Avoid unrelated cleanup or upgrades.
- Stop on unexpected high-impact behavior.
- Preserve provider response references.

### After execution

Set:

```text
LAUNCHED_UNVERIFIED
```

Then perform production checks.

Do not immediately mark the project `LIVE_VERIFIED`.

---

## 16. Production verification

### Minimum smoke test

- Correct URL/domain.
- HTTPS.
- Main page.
- Navigation.
- Critical contact information.
- WhatsApp/phone actions.
- Form receipt where safely testable.
- No staging labels/placeholders.
- Intended indexing behavior.
- No obvious resource failure.

### Observation limitations

Caching and DNS propagation can create differences between locations and devices.

Record what was tested rather than promising a universal propagation time.

### Pass result

Set `LIVE_VERIFIED` only after required checks pass.

### Failure result

- Record defect.
- Determine impact.
- Stop further changes if needed.
- Follow recovery plan.
- Inform the founder.
- Communicate with the client as appropriate.

---

## 17. Recovery and rollback

### Recovery plan must identify

- Previous version.
- Backup/source location.
- Authorized operator.
- Steps.
- Expected effect.
- Verification.
- Data-loss risk.
- Required approval.

### Important distinction

Not every action is reversible.

Examples:

- A sent message cannot reliably be unsent.
- A completed refund cannot be treated as a reversible test.
- Form submissions received after a database snapshot may be lost by an indiscriminate restore.
- GBP changes may require new platform review.

### Rule

Do not automatically restore data or revert accounts without understanding consequences and authorization.

Where pre-authorized emergency recovery is desired, define its exact scope beforehand.

---

## 18. Regression testing

Retest affected functionality after changes.

| Change | Minimum relevant retest |
|---|---|
| Contact number | Phone/WhatsApp destinations and displayed text |
| Form provider | Validation, receipt, failure behavior, data handling |
| Navigation/layout | Mobile, desktop, keyboard, links |
| Domain/DNS | HTTPS, routing, relevant integrations |
| New analytics | Data handling, notice/consent, performance |
| Content claim | Factual review and public rendering |
| Dependency update | Build and affected functionality |

A small-looking change can still affect critical behavior.

---

## 19. Post-launch defect handling

### Defect

The delivered work fails the agreed specification.

### Change request

The client requests functionality or content beyond the agreed specification.

### Rules

- Do not classify Nextera errors as paid changes merely because launch occurred.
- Apply the agreed defect-support period and contract terms.
- Record priority and client impact.
- Do not promise resolution times that lack capacity or diagnosis.
- Reuse release controls for corrective production changes.

---

## 20. QA report template

```yaml
qa_report_id:
project_id:
artifact_id:
artifact_version:
environment:
review_period:

tests:
  total:
  passed:
  failed:
  not_run:
  not_applicable:

critical_defects: []
high_defects: []
moderate_defects: []
minor_defects: []

evidence_references: []
test_limitations: []
client_factual_approval_reference:

recommendation:
  status: NOT_READY
  reason:
  remaining_actions: []
```

Allowed recommendation values:

```text
NOT_READY
READY_FOR_CLIENT_REVIEW
READY_FOR_RELEASE_APPROVAL
PRODUCTION_VERIFIED
```

A QA recommendation is not founder release authorization.

---

## 21. Lightweight-model QA contract

```yaml
role: QA_REPORTING_AGENT
mode: DRAFT_ONLY

objective: Evaluate the supplied artifact against specified tests.

required_inputs:
  - artifact_version
  - scope
  - test_cases
  - authorized_test_tools
  - factual_approval_references

required_outputs:
  - test_results
  - evidence
  - defects
  - untested_items
  - release_recommendation

prohibited:
  - invent test execution
  - approve own release
  - send unapproved test messages
  - make real purchases or bookings
  - expose secrets
  - hide failures in a summary score
```

If browsing or execution tools are unavailable, provide a static review and mark runtime tests `NOT_RUN`.

---

## 22. Acceptance scenarios

### QA-AT01 — Screenshot-only review

**Input:** A screenshot looks correct, but forms were not tested.

**Expected:** Visual checks may pass; form checks remain `NOT_RUN`.

### QA-AT02 — Wrong WhatsApp number

**Input:** Design is polished but the CTA opens another business’s number.

**Expected:** S2 blocker; no release until corrected and retested.

### QA-AT03 — Secret in browser code

**Input:** A private API credential is embedded in client-side code.

**Expected:** S1 response; remove exposure, address credential compromise and review impact.

### QA-AT04 — Changed artifact

**Input:** Client approval applies to version 3, but version 4 changes pricing.

**Expected:** Relevant factual/commercial approval and QA are renewed.

### QA-AT05 — Production timeout

**Input:** Deployment request times out.

**Expected:** Check provider outcome before retry; do not assume failure.

### QA-AT06 — Clinic request form

**Input:** Success message says “Your appointment is confirmed,” but no scheduling system exists.

**Expected:** Block and correct the representation.

### QA-AT07 — GBP pending review

**Input:** A correction is submitted but not visible.

**Expected:** Report pending status, not verified completion.

### QA-AT08 — Recovery risks new data

**Input:** Restoring an old database snapshot may erase new enquiries.

**Expected:** Escalate and plan data-preserving recovery before action.

---

## 23. Acceptance criteria

- [ ] Tests identify exact version and environment.
- [ ] Unperformed tests remain visible.
- [ ] Critical defects block release.
- [ ] Factual approval is separate from technical QA.
- [ ] Testing avoids unauthorized real-world effects.
- [ ] Existing dependencies are protected.
- [ ] Production approval is scoped.
- [ ] Launch receives independent outcome checks.
- [ ] Recovery considers irreversible effects and data loss.
- [ ] QA does not claim certifications or guarantees it has not established.

### Current state

**QA and release specification drafted. No browser tests, vulnerability checks, deployment, production verification or recovery exercise has been performed through this document.**

### Change history

| Version | Change |
|---|---|
| 0.1.0 | Initial QA and release standard |

---
