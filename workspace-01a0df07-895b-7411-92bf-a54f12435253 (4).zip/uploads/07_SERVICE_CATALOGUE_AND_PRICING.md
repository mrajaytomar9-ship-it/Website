```yaml
document_id: NXT-BIZ-003
title: Service Catalogue, Packaging and Pricing Rules
version: 0.1.0
document_status: DRAFT
owner_role: FOUNDER
approval_status: PENDING
approved_by: null
approval_reference: null
effective_date: null
last_updated: SET_WHEN_SAVED
information_classification: INTERNAL
canonical_location: TO_BE_ASSIGNED
related_documents:
  - NXT-GOV-001
  - NXT-GOV-003
  - NXT-BIZ-001
  - NXT-BIZ-002
```

## 1. Purpose

This document defines:

- What Nextera intends to sell.
- What each service includes.
- What is excluded.
- Proposed prices.
- Client responsibilities.
- Revision and support boundaries.
- Approval requirements.
- Rules for customization and future services.

Its primary purpose is to prevent overselling, inconsistent quoting and unlimited scope.

This is not yet a public price list or finalized service agreement.

---

## 2. Catalogue status and authority

### Confirmed direction

- Websites.
- WhatsApp enquiry setup.
- GBP work.
- Recurring service revenue.
- Voice and advanced automation later.

### Proposed commercial decisions

The following remain subject to approval:

- Package names.
- ₹6,000 pilot.
- ₹15,000 foundation.
- ₹4,000 monthly care.
- 50% advance / 50% before launch.
- Two revision rounds.
- Specific monthly allowances.
- Support windows and turnaround standards.

Relevant decision references:

```text
DEC-034: Payment structure
DEC-035: Test prices
DEC-036: Revision rounds
DEC-047: Support hours
```

### Agent rule

Do not send a final quote based only on this draft.

A quote must reference:

1. Approved catalogue version; or
2. A founder-approved client-specific commercial decision.

---

## 3. Packaging philosophy

### 3.1 Sell a business use case

Use:

> “A professional website and clearer enquiry path.”

Avoid:

> “An army of AI agents that guarantees customers.”

### 3.2 Reusable foundation, tailored presentation

Proposed delivery approach:

- Reusable technical components.
- Defined design standards.
- Client-specific branding.
- Approved business content.
- Appropriate enquiry flow.
- Consistent QA.

Do not imply every component is custom-built from zero.

### 3.3 Narrow promises

A package is a defined set of deliverables, not a guarantee of business performance.

### 3.4 Separate setup and recurring value

Setup produces agreed assets and configuration.

Recurring service provides defined ongoing maintenance, updates and monitoring.

Neither automatically includes the other.

---

## 4. Service inventory

| Service ID | Service | Initial status |
|---|---|---|
| SVC-WEB-01 | One-page presence website | Proposed initial |
| SVC-WEB-02 | Small multi-page website | Proposed initial |
| SVC-WA-01 | Click-to-WhatsApp enquiry setup | Proposed initial |
| SVC-GBP-01 | GBP audit | Proposed initial |
| SVC-GBP-02 | Authorized GBP corrections | Proposed initial |
| SVC-CARE-01 | Website care and scoped updates | Proposed recurring |
| SVC-REP-01 | Review-response assistance | Proposed recurring |
| SVC-REP-02 | Genuine review-request guidance | Proposed recurring |
| SVC-RPT-01 | Basic reporting and recommendations | Proposed recurring |
| SVC-SEO-01 | Expanded local SEO/content work | Custom scope later |
| SVC-WA-02 | Official API messaging | Not ready for sale |
| SVC-VOICE-01 | AI voice agent | Not ready for sale |
| SVC-OS-01 | Client-facing Nextera OS | Future concept |

“Proposed initial” does not mean technically tested.

---

## 5. Package A — Presence Pilot

```yaml
package_id: PKG-PILOT-01
package_version: 0.1
commercial_status: PROPOSED
proposed_setup_price_inr: 6000
billing_type: ONE_TIME
```

### Intended buyer

A qualified business needing a limited first improvement without a full multi-page project.

### Intended outcome

A clearer, more professional public introduction and enquiry path.

### Included

- One responsive page.
- Up to six standard content sections.
- One primary language.
- One authorized WhatsApp click-to-chat action.
- One minimal enquiry form, subject to suitable authorized form handling.
- Contact/location information.
- Basic page title and description.
- GBP audit with prioritized findings.
- Staging preview.
- Defined QA and handover.

### Content preparation

Nextera may turn supplied, approved facts into concise website copy.

Included copy work does not include:

- Extensive interviews.
- Independent verification of every business claim.
- Medical claim development.
- Full brand strategy.
- Unlimited rewriting.

### Excluded

- GBP correction execution.
- Booking engine.
- Patient portal.
- Payment gateway.
- Custom database.
- Official WhatsApp API.
- AI chatbot or voice agent.
- Ongoing SEO.
- Ongoing maintenance.
- Multilingual implementation.
- Professional photography.
- Logo redesign.
- Migration of a complex existing site.

### Delivery timing

**Proposed planning range:** 3–5 working days after:

- Scope acceptance.
- Agreed advance verification.
- Required inputs.
- Capacity confirmation.

This is not an automatic contractual deadline. The founder must approve the actual project schedule.

### Acceptance

- Agreed sections exist.
- Approved facts are represented correctly.
- Mobile layout is usable.
- Contact actions work.
- Form receipt is tested where included.
- No unresolved release blocker.
- Client review and launch approval are recorded.

---

## 6. Package B — Presence Foundation

```yaml
package_id: PKG-FOUNDATION-01
package_version: 0.1
commercial_status: PROPOSED
proposed_setup_price_inr: 15000
billing_type: ONE_TIME
```

### Intended buyer

A business requiring a more complete website and coordinated public information.

### Included

- Up to five standard pages.
- One primary language.
- Shared design system.
- Client-specific logo, colors and content.
- Mobile-responsive implementation.
- Up to two agreed enquiry entry points using one defined routing method.
- Click-to-WhatsApp.
- Basic titles, descriptions and logical page structure.
- GBP audit.
- One approved batch of routine GBP corrections where access and platform rules permit.
- Basic measurement setup where technically and legally appropriate.
- Staging, QA, launch and handover.

### Example hotel page structure

```text
Home
Rooms / Stay Options
Property / Amenities
Location / Visitor Information
Contact / Enquiry
```

### Example clinic page structure

```text
Home
About / Approved Practitioner Information
Services
Clinic Information / Administrative FAQs
Contact / Appointment Request
```

These are examples, not mandatory layouts.

### GBP correction boundaries

Possible approved corrections:

- Contact details.
- Website URL.
- Hours.
- Description.
- Appropriate business information.
- Client-provided images.

Excluded:

- Guaranteed verification.
- Suspension recovery.
- Ownership disputes.
- Duplicate-profile resolution.
- Ranking guarantees.
- False categories or keyword-stuffed business names.

### Delivery timing

**Proposed planning range:** 7–10 working days after required inputs and capacity confirmation.

Integration complications, client delays and platform reviews require separate treatment.

### Excluded

Everything excluded from the pilot unless explicitly added, plus:

- Unlimited page creation.
- Complex CMS migration.
- Multi-location architecture.
- Custom integrations.
- Large content libraries.
- Full search strategy or backlink campaigns.

---

## 7. Package C — Care & Presence

```yaml
package_id: PKG-CARE-01
package_version: 0.1
commercial_status: PROPOSED
proposed_monthly_price_inr: 4000
billing_type: RECURRING
minimum_term: UNDECIDED
support_hours: UNDECIDED
```

### Intended buyer

A business with a maintainable website and a genuine need for recurring presence work.

### Entry conditions

Before acceptance:

- Website technology is identified.
- Account access is authorized.
- Existing defects are reviewed.
- Backup/recovery feasibility is understood.
- Required remediation is separately scoped.

A pre-existing broken website is not automatically repaired under the monthly fee.

### Proposed monthly allowance

| Deliverable | Limit |
|---|---|
| Small website updates | Up to two requests |
| GBP posts/updates | Up to four, where appropriate and authorized |
| Review-response drafts | Up to 20 |
| Enquiry-flow check | One scheduled cycle |
| Monthly report | One |
| Improvement recommendation | One prioritized recommendation |

### Small update definition

A request changes existing content without introducing new functionality or design structure.

Examples:

- Replace approved text on an existing page.
- Update hours.
- Replace a supplied image.
- Correct an existing contact detail.

Non-examples:

- New page.
- Redesign.
- Booking feature.
- New integration.
- Full copy rewrite.
- New language.

### Additional scope ceiling

**Proposed:** one small update covers one existing page and up to three existing text/image blocks.

If the request exceeds that boundary, create a change request.

### Maintenance definition

Maintenance tasks depend on the agreed stack.

Document explicitly:

- What is checked.
- Whether backups are included.
- Whether dependency updates apply.
- What failures are covered.
- What requires separate remediation.

Do not claim “complete security” or “all issues fixed.”

### Reporting

Include:

- Work completed.
- Issues detected.
- Available engagement/enquiry metrics.
- Source and limitations.
- Next recommendation.
- Client action required.

No invented revenue attribution.

### Allowance treatment

**Proposed:**

- Monthly allowances do not accumulate.
- Unused deliverables are not replaced with unrelated work.
- Scope substitutions require agreement.
- Delay caused by missing client inputs is recorded.
- No obligation to publish low-quality content merely to fill a quota.

### Not included

- Daily monitoring unless separately configured.
- 24/7 support.
- Unlimited requests.
- Continuous lead generation.
- Full SEO campaign.
- Paid ads.
- Messaging/calling usage.
- Major malware recovery.
- Full redesign.
- Content requiring specialized professional review.

---

## 8. Niche-specific boundaries

### 8.1 Hotels

Allowed initial functions:

- Property information.
- Approved room descriptions.
- Amenities.
- Location.
- Enquiry links.
- Booking-request routing.

Not allowed without a verified integration:

- Live availability claims.
- Confirmed reservations.
- Automated rate promises.
- Discount commitments.
- Refund decisions.

### 8.2 Clinics

Allowed initial functions:

- Approved business/practitioner information.
- Timings.
- Location.
- Administrative FAQs.
- Appointment requests.

Excluded:

- Diagnosis.
- Medical advice.
- Prescription support.
- Unnecessary health-data collection.
- Confirmed scheduling without authorization.
- Invented qualifications or treatment outcomes.

Clinic content requires an authorized factual approver.

---

## 9. Revision policy

### Proposed standard

Two consolidated revision rounds.

### A revision round means

The client submits one organized feedback list against the current preview.

### Included revisions

- In-scope text adjustments.
- Image replacements.
- Minor layout adjustments within the agreed design direction.
- Corrections to match approved requirements.

### Not treated as chargeable revisions

Nextera correcting its own failure to meet the agreed specification.

Defect correction must not be misclassified as a paid change request.

### Out-of-scope changes

- New design direction after approval.
- Additional pages/features.
- Additional language.
- Replacement of the underlying platform.
- New third-party integration.

### Defect reporting period

A post-launch defect-support period must be specified in the client agreement. It is not finalized by this draft.

---

## 10. Client responsibilities

The client must provide or authorize:

- Accurate business information.
- Appropriate decision-maker.
- Licensed or owned assets.
- Account access through suitable methods.
- Factual content approval.
- Timely consolidated feedback.
- Applicable payment.
- Staff participation where a new enquiry process requires it.

### Client delay rule

A missed input or approval may change the schedule under agreed terms.

Nextera must communicate the impact rather than silently changing deadlines.

Client silence does not automatically authorize publication of uncertain facts.

---

## 11. Pricing and cost rules

### 11.1 Prices are hypotheses

The proposed prices are not verified market rates.

Review them using:

- Paid acceptance.
- Delivery effort.
- Rework.
- Direct costs.
- Support load.
- Client value.
- Margin.

### 11.2 Quote calculation

```text
Approved base scope
+ approved add-ons
+ separately disclosed external costs
+ applicable taxes, if any
= quoted amount
```

Tax applicability and presentation require appropriate review.

### 11.3 Contribution check

```text
Expected contribution
= package fee
− direct infrastructure/usage costs
− outsourced work
− other client-specific costs
```

Also estimate founder hours.

A positive cash contribution does not automatically make a package sustainable.

### 11.4 Discount rule

Only the founder may approve discounts.

Record:

- Original price.
- Discount.
- Reason.
- Scope effect.
- Expiry.
- Whether recurring fees are affected.

Do not invent “limited-time” urgency.

### 11.5 Low-budget prospect

Options:

- Narrower deliverables.
- Phased work.
- Decline respectfully.

Do not promise the full package at a loss without explicit founder consideration.

---

## 12. Payment structure

### Proposed default

- 50% advance.
- 50% before public launch under agreed terms.
- Recurring fees billed in advance under the recurring agreement.

### Before taking money

Confirm:

- Scope.
- Authorized client.
- Invoice identity.
- Payment destination.
- Milestones.
- Cancellation terms.
- External costs.
- Expected schedule and dependencies.

### Important distinctions

- Invoice sent ≠ payment received.
- Payment screenshot ≠ automatically verified settlement.
- Advance received ≠ work completed.
- Unpaid invoice ≠ permission to delete client data.

### Refund/cancellation

No universal non-refundable rule is established here.

Terms must account for the agreement, work completed and applicable obligations.

Founder approval is required for refunds.

---

## 13. Third-party services

### Client-specific dependencies

Potential examples:

- Domain registration.
- Hosting.
- Form handling.
- Analytics.
- Messaging APIs.
- Telephony.
- Model usage.
- Licensed assets.

### Rules

- Identify the owner of each account.
- Disclose recurring costs and renewal terms.
- Check commercial-use suitability.
- Do not guarantee a free tier will remain available.
- Do not use a free subdomain as though it is a client-owned custom domain.
- Do not buy a service without authorization.

### Ownership baseline

Proposed approach:

- Client owns their domain and business profiles.
- Access is delegated where supported.
- Nextera retains its reusable pre-existing components unless the contract says otherwise.
- Client receives the agreed deliverable and disclosed usage rights.
- Third-party licenses remain subject to their own terms.

The final contract must distinguish client content, delivered work, reusable components and third-party materials.

---

## 14. Custom quotes and add-ons

Potential add-ons:

- Additional standard page.
- Additional language.
- Extra approved content.
- Additional revision round.
- Existing-site remediation.
- Specialized integration.
- Expanded recurring work.

No universal add-on price is established yet.

### Custom-quote record

```yaml
quote_id:
client_id:
catalogue_version:
base_package:
requested_additions: []
excluded_items: []

delivery_dependencies: []
estimated_founder_effort:
direct_cost_estimate:
proposed_price:
applicable_tax_treatment:
timeline:

founder_approval_reference:
client_acceptance_reference:
```

Agents may draft this record but cannot finalize price or schedule.

---

## 15. Services not ready for sale

### AI voice agents

Required before sale:

- Defined use case.
- Appropriate consent/disclosure handling.
- Telephony provider.
- Verified information source.
- Human escalation.
- Usage-cost model.
- Call testing.
- Failure handling.
- Client agreement.

### Official WhatsApp automation

Required before sale:

- Suitable official integration.
- Account authorization.
- Applicable messaging rules.
- Consent/opt-out handling.
- Template/process requirements where applicable.
- Cost limits.
- Monitoring.
- Manual fallback.

### Nextera OS

Not a current deliverable.

Requires separate validation, PRD, architecture, security and support model.

A virtual-office tool is not automatically a customer-facing platform.

---

## 16. Quote-readiness checklist

A final quote is ready only when:

- [ ] Buyer authority is known.
- [ ] Scope fits current capability.
- [ ] Package or custom price is founder-approved.
- [ ] Dependencies are identified.
- [ ] External costs are disclosed.
- [ ] Timeline is capacity-checked.
- [ ] Revisions and exclusions are clear.
- [ ] Payment/cancellation terms are included.
- [ ] Support scope is defined.
- [ ] No unsupported guarantees appear.

If any critical item is missing, return:

```text
NEEDS_INPUT
NEEDS_DECISION
or
NEEDS_APPROVAL
```

---

## 17. Lightweight-model offer-selection contract

```yaml
role: SALES_ASSISTANT
mode: DRAFT_ONLY
objective: Recommend an appropriate package from the supplied catalogue.

inputs_required:
  - prospect_problem
  - required_deliverables
  - existing_assets
  - technical_dependencies
  - approved_catalogue_status

required_output:
  - recommended_package_or_custom_scope
  - scope_fit_reason
  - exclusions_to_explain
  - missing_inputs
  - founder_decisions_required
  - draft_only_status

prohibited:
  - invent prices
  - convert proposed pricing into approved pricing
  - promise bookings or rankings
  - include unavailable integrations
  - send the quote
```

### Example routing

```text
Needs only a one-page presence and enquiry path:
Consider Presence Pilot.

Needs several business-information pages and authorized GBP cleanup:
Consider Presence Foundation.

Needs ongoing scoped care for a maintainable site:
Consider Care & Presence.

Needs booking engine, clinical system or voice automation:
Do not force-fit into an initial package.
Return custom-scope or not-ready-for-sale assessment.
```

---

## 18. Commercial acceptance tests

### CAT-01 — Pilot misunderstanding

**Input:** Prospect expects full SEO and unlimited changes for the pilot fee.

**Expected:** Clarify exclusions before acceptance.

### CAT-02 — Agent discount

**Input:** Prospect asks the agent for 30% off.

**Expected:** Agent may record the request; founder decides.

### CAT-03 — Clinic automation request

**Input:** Clinic asks the website assistant to recommend treatments.

**Expected:** Decline that scope and route clinical questions to appropriate professionals.

### CAT-04 — Existing broken site

**Input:** Prospect requests monthly care and immediate repair of a heavily broken site.

**Expected:** Audit/remediation assessment before retainer acceptance.

### CAT-05 — Unverified paid status

**Input:** Client says they paid, but receipt is unverified.

**Expected:** Mark verification pending; do not fabricate settlement.

### CAT-06 — Free-hosting assumption

**Input:** Agent proposes permanent free hosting.

**Expected:** Review terms and limits; avoid permanence guarantee.

### CAT-07 — Incorrect business detail

**Input:** Delivered phone number differs from approved scope.

**Expected:** Treat as defect correction, not a paid revision.

---

## 19. Acceptance criteria

- [ ] Every package has a use case and bounded scope.
- [ ] Proposed prices remain visibly unapproved.
- [ ] Initial services are separated from future services.
- [ ] Setup and recurring obligations are distinct.
- [ ] Revision and defect treatment are separate.
- [ ] Third-party costs and ownership are disclosed.
- [ ] Timeline requires inputs and capacity confirmation.
- [ ] Healthcare and hotel limitations are explicit.
- [ ] Agents cannot independently quote, discount or commit.
- [ ] Final terms can be transferred into a client-specific agreement.

### Current state

**Catalogue draft complete. Pricing, commercial terms, delivery timing and support allowances require approval and real-world validation before public use.**

### Change history

| Version | Change |
|---|---|
| 0.1.0 | Initial detailed service and pricing specification |

---
