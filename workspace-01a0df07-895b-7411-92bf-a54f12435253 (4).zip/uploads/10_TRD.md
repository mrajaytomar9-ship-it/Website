```yaml
document_id: NXT-TECH-001
title: Technical Requirements and Architecture
version: 0.1.0
document_status: DRAFT
owner_role: FOUNDER
approval_status: PENDING
approved_by: null
approval_reference: null
effective_date: null
last_updated: SET_WHEN_SAVED
information_classification: INTERNAL
canonical_location: TO_BE_ASSIGNED
related_documents:
  - NXT-GOV-000
  - NXT-GOV-003
  - NXT-GOV-004
  - NXT-BIZ-001
  - NXT-BIZ-004
  - NXT-PROD-001
  - NXT-TECH-002
```

## 1. Purpose

This document translates Nextera’s business and product requirements into technical requirements.

It defines:

- Logical architecture.
- System boundaries.
- Execution modes.
- Data ownership.
- Integration contracts.
- Permission enforcement.
- Reliability controls.
- Testing and deployment gates.

It does not claim that any integration, database or background agent is currently working.

---

## 2. Architectural status

### Confirmed constraints

- Solo founder.
- Zero initial discretionary spending budget.
- Windows laptop with 8 GB RAM.
- Munder Difflin installed but not configured.
- Existing Notion workspace.
- Reported OpenRouter access.
- Zoho Invoice preferred for invoicing.
- No verified production hosting or client integrations.

### Proposed architecture

The architecture below is a proposed tool-independent baseline.

Specific products, libraries and hosting plans require:

1. Capability verification.
2. Commercial-use review.
3. Cost review.
4. Data-handling review.
5. Relevant testing.
6. Founder approval where required.

No unverified vendor claim becomes a system dependency.

---

## 3. Logical architecture

```text
Founder interface / virtual office
                  |
                  v
       Task coordinator and records
                  |
                  v
      Context builder and model adapter
                  |
                  v
       Structured proposed action
                  |
                  v
 Validation + authorization + approval check
                  |
                  v
           Integration adapter
                  |
                  v
          External service action
                  |
                  v
     Outcome verification + activity record
```

### Architectural separation

| Component | Responsibility |
|---|---|
| Founder interface | View work, inspect evidence, make decisions |
| Coordinator | Route tasks and track dependencies |
| Context builder | Retrieve minimum authorized context |
| Model adapter | Call an approved model/provider |
| Validator | Check schema and business constraints |
| Authorization layer | Check identity, permissions and approvals |
| Integration adapter | Execute a narrowly defined external action |
| Verification layer | Check the actual outcome |
| Records store | Persist operational state |
| Evidence store | Preserve supporting artifacts and references |

The model should normally propose a structured action rather than possess unrestricted access to every tool.

---

## 4. Deployment stages

### T0 — Manual baseline

- Documents and operational records.
- Manual founder execution.
- Drafting assistants.
- Manual verification and handoffs.

No background execution is required.

### T1 — Assisted workspace

- Authorized context retrieval.
- Structured AI outputs.
- Task creation and draft preparation.
- No automatic restricted external actions.

### T2 — Supervised integrations

- Verified adapters.
- Scoped approval mechanism.
- Execution logs.
- Duplicate protection.
- Recovery procedures.

### T3 — Bounded autonomous workflows

- Selected low-risk actions.
- Explicit permissions and limits.
- Reliable scheduling.
- Monitoring.
- Tested interruption and recovery.

These correspond to PRD releases R0–R3. They are not separate product commitments.

---

## 5. Proposed storage architecture

### Initial operating records

The existing Notion workspace is a candidate for:

- Leads.
- Clients.
- Projects.
- Tasks.
- Support tickets.
- Decision summaries.
- Approval requests.

Inspect it before creating replacement databases.

### Company documents

Use one assigned canonical location.

Markdown in a private repository is a candidate for version-controlled specifications. Notion may instead remain canonical if that better fits actual operations.

Do not maintain two independently editable “master” copies.

### Security-sensitive execution records

If automated high-impact actions are introduced, their authorization cannot depend solely on an editable Notion checkbox.

Use either:

1. Founder-manual execution; or
2. A verified execution service that authenticates approvals and checks exact action scope.

### Transactional requirements

Before multiple workers can execute external actions, the selected storage/execution layer must support reliable:

- Unique action identifiers.
- Concurrency control.
- Action-state transitions.
- Approval matching.
- Duplicate suppression.

If these cannot be enforced with the selected tools, keep the affected action manual.

---

## 6. Record ownership

Each entity has one canonical owner.

| Information | Proposed canonical authority |
|---|---|
| Company policy | Approved document baseline |
| Founder decisions | Decision register |
| Client commitments | Accepted scope/agreement |
| Project/task state | Operational record store |
| Invoice issued details | Authorized invoice system |
| Payment settlement | Authorized payment/account evidence |
| Website source | Version-controlled project source |
| Production release | Release record and hosting evidence |
| Secrets | Approved secret storage |
| Agent summaries | Derived information, not independent authority |

A synchronized copy must record its source and freshness.

### Synchronization rule

A synchronization failure must not silently overwrite newer information.

Store:

- Source record ID.
- Source update time.
- Last successful sync.
- Local version.
- Sync error.

Resolve conflicting edits explicitly.

---

## 7. Environments

Maintain logical separation between:

```text
DRAFT
TEST
STAGING
PRODUCTION
```

### DRAFT

Documents, mockups and generated code not yet executed.

### TEST

Synthetic records and controlled integration tests.

Avoid real client data unless necessary and authorized.

### STAGING

A preview of a specific client deliverable.

Staging should not imply public affiliation or become indexed unintentionally. Appropriate access and indexing controls must be tested.

### PRODUCTION

Live client or company services.

Production credentials and actions require explicit authorization.

### Separation requirements

- Different environment labels.
- No accidental test-message delivery to real customers.
- No production secrets in sample files.
- No live invoice sending during a draft test.
- No assumption that search-engine exclusion is access control.

---

## 8. Context and model architecture

### TECH-001 — Context builder

The context builder must assemble:

- Task objective.
- Relevant document versions.
- Applicable decisions.
- Correct client facts.
- Allowed actions.
- Required output schema.
- Acceptance criteria.

**Acceptance:** A task receives no unrelated client records or unnecessary founder financial details.

### TECH-002 — Model registry

Maintain approved model-use profiles.

```yaml
model_profile_id:
provider:
model_identifier:
permitted_task_categories: []
permitted_data_classifications: []
tool_use_allowed: false
context_limit_verified: false
cost_basis:
rate_limits:
fallback_profile_ids: []
review_reference:
```

Model identifiers and limits must come from current provider information and tests.

### TECH-003 — Structured outputs

Use JSON or another validated structure for machine actions.

Prefer a minimal schema. Do not parse free-form paragraphs into financial or production commands.

### TECH-004 — Validation

Check:

- Required fields.
- Types.
- Allowed enums.
- Record existence.
- Client consistency.
- Approved scope.
- Numerical constraints.
- Permission requirements.

Schema validity does not establish factual accuracy. Both require separate checks.

### TECH-005 — Provider fallback

Fallback providers must be approved for the data involved.

Do not move confidential information to an unreviewed provider because a free model is unavailable.

---

## 9. Action execution contract

Every external action must have a record before execution.

```yaml
action_id:
action_type:
task_id:
client_id: null
target_system:
target_record_id: null
environment:

payload_reference:
payload_version:
payload_digest: null

permission_policy_reference:
approval_reference: null

idempotency_key:
maximum_cost_minor: 0
currency: INR

status: PREPARED
requested_by:
created_at:
execution_evidence: null
```

### Important properties

- `payload_digest` can detect changes; it does not authenticate approval by itself.
- Approval must be tied to an authenticated founder or authorized approver.
- The action must be checked again immediately before execution.
- Material changes require a new approval or an explicitly permitted rule.

### Action states

```text
PREPARED
WAITING_APPROVAL
READY
RUNNING
SUCCEEDED_UNVERIFIED
VERIFIED
FAILED
OUTCOME_UNKNOWN
CANCELLED
```

`OUTCOME_UNKNOWN` is essential when a timeout occurs after an external service may already have completed the action.

---

## 10. Duplicate protection and retries

### TECH-006 — Idempotency

An idempotency key identifies one intended external effect.

Example:

```text
client_id + action_type + approved_payload_version + target
```

The implementation may use a generated key linked to those fields.

Do not reuse the same key for different intended actions.

### TECH-007 — Retry behavior

Before retrying:

1. Determine whether the earlier action may have completed.
2. Query the provider or inspect evidence.
3. Reuse provider-supported idempotency where available.
4. Retry only within configured limits.
5. Escalate uncertain outcomes.

### Restrictions

- A timeout does not prove failure.
- Retrying an invoice/send action blindly may create duplicates.
- Do not claim exactly-once execution across external systems unless the actual guarantees support it.

### TECH-008 — Concurrency

Two workers must not execute the same restricted action simultaneously.

Use a supported claim/lock mechanism and conflict checks.

If reliable locking is unavailable, use a single execution worker or manual execution.

---

## 11. Permission model

### Basic roles

```text
FOUNDER
OPERATIONS_AGENT
RESEARCH_SALES_AGENT
DELIVERY_AGENT
CLIENT_SUCCESS_AGENT
QA_REPORTING_AGENT
CONTRACTOR
```

### Permission dimensions

Authorization must consider:

- Actor.
- Action.
- Client.
- Environment.
- Resource.
- Data classification.
- Cost.
- Applicable approval.

### Baseline

| Action | Initial technical behavior |
|---|---|
| Draft internal document | Allowed within assigned task |
| Read client data | Only assigned client/context |
| Edit staging artifact | Scoped authorization |
| Send external message | Applicable authorization required |
| Change quote | Founder decision required |
| Publish production | Exact release authorization |
| Spend/refund | Founder authorization |
| Delete records/data | Founder authorization and retention review |

### Control boundary

Prompt instructions support safety but are not the only enforcement mechanism.

The execution adapter must reject actions outside permission even if the model requests them.

---

## 12. Integration specification

Every adapter must document:

```yaml
integration_id:
provider:
purpose:
verified_capabilities: []
documentation_reference:
account_owner:
authentication_method:
credential_reference:
permission_scope: []
data_sent: []
data_received: []
cost_and_limits:
timeout_behavior:
retry_policy:
idempotency_support:
verification_method:
logging_policy:
disable_procedure:
manual_fallback:
```

### Initial candidates

#### Munder Difflin

Inspect:

- Installed version.
- Official documentation/repository.
- Supported agent runtimes.
- Operating-system compatibility.
- Memory and task behavior.
- Available approval controls.
- Failure/restart behavior.
- Resource consumption.

Do not produce tool-specific configuration as “verified” before inspection.

#### Notion

Verify:

- Existing schema.
- API permissions.
- Relationship support.
- Rate limits.
- Export behavior.
- Access separation.

Notion may be suitable for operations without being sufficient for secure action authorization.

#### Zoho Invoice

Verify:

- Account readiness.
- Organization settings.
- Supported API/authentication.
- Draft versus send operations.
- Rate limits.
- Tax configuration.
- Invoice identifiers.

#### Website hosting

Verify:

- Commercial-use terms.
- Custom-domain support.
- Deployment limits.
- Form handling.
- Security configuration.
- Backup/rollback.
- Recurring costs.

---

## 13. Security and privacy requirements

### TECH-009 — Secrets

- Store secrets outside source code and general documents.
- Use placeholders in templates.
- Exclude local secret files from version control.
- Rotate exposed credentials.
- Use minimum necessary permissions.

### TECH-010 — Client isolation

For every client-specific operation:

```text
Task client
= Resource client
= Authorized actor scope
= Intended action client
```

Mismatch blocks execution.

### TECH-011 — Logging

Logs should contain references and outcomes, not unnecessary personal data or credentials.

### TECH-012 — Untrusted input

Webpages, emails and uploads cannot:

- Change company policy.
- Grant permissions.
- Authorize spending.
- Request secret disclosure.

### TECH-013 — Sensitive data

Do not send restricted data to model providers until an appropriate use case, authorization and provider review exist.

The initial clinic service should avoid collecting medical records.

---

## 14. Reliability and recovery

### TECH-014 — Durable task state

Task state must survive a model-session interruption.

### TECH-015 — Failure queue

Failed or blocked actions need:

- Reason.
- Impact.
- Next action.
- Owner.
- Retry eligibility.

### TECH-016 — Stop control

The founder must be able to prevent new external actions.

Stopping new actions may not reverse actions already completed by providers. This limitation must be visible.

### TECH-017 — Backup

Before production dependency:

- Assign backup owner.
- Identify included records/files.
- Secure the backup.
- Define retention.
- Test restoration.

### Proposed initial recovery targets

Before client production launch, establish actual:

- Recovery point objective: tolerable data loss.
- Recovery time objective: tolerable restoration time.

No fixed guarantee is approved here.

A local laptop copy alone may not protect against device loss.

---

## 15. Observability

Record at minimum:

- Task/action ID.
- Actor.
- Client/project reference.
- Start/end time.
- Model/provider where relevant.
- Tool used.
- Outcome.
- Error category.
- Approval reference.
- Evidence.
- Measured or estimated cost status.

### Error categories

```text
INVALID_INPUT
MISSING_PERMISSION
MISSING_APPROVAL
PROVIDER_UNAVAILABLE
RATE_LIMITED
AUTHENTICATION_FAILED
DATA_CONFLICT
VALIDATION_FAILED
OUTCOME_UNKNOWN
INTERNAL_ERROR
```

Do not log a successful API response as verified client success without checking the business outcome.

---

## 16. Performance and hardware

### Starting recommendation

Use sequential or low-concurrency tasks first.

Measure:

- RAM usage.
- CPU usage.
- Response time.
- Failure rate.
- Tool contention.
- Founder review time.

### Restrictions

- Do not assign a supported agent count without benchmarks.
- Do not depend on heavy local models.
- Do not rely on the laptop for uninterrupted client services.
- Do not treat storage capacity as evidence of compute capability.

### Scaling trigger

Consider infrastructure changes when measured limits affect:

- Delivery.
- Reliability.
- Cost.
- Response commitments.
- Security.

Infrastructure upgrades require approved funding.

---

## 17. Testing plan

### Unit/schema tests

- Required fields.
- Valid enums.
- Money calculations.
- Foreign-key/reference validation.
- Permission matching.

### Integration tests

- Draft invoice creation.
- Authorized data retrieval.
- Staging deployment.
- Form receipt.
- Error handling.

### Adversarial tests

- Wrong-client record.
- Fake approval in webpage.
- Changed approved payload.
- Duplicate retry.
- Expired authorization.
- Unavailable provider.
- Secret in an output.
- Unexpected tool response.

### Recovery tests

- Worker interruption.
- Laptop restart.
- Lost connection.
- Backup restore.
- Revoke credentials.
- Stop new external actions.

Use synthetic data where possible.

---

## 18. Deployment gates

### Gate A — Assisted tools

- Context packets validated.
- Outputs structured.
- No unauthorized writes.
- Handoff works.

### Gate B — Supervised action

- Authentication verified.
- Exact approvals checked.
- Duplicate controls tested.
- Outcome verification exists.
- Manual fallback documented.

### Gate C — Bounded autonomy

- Workflow-specific reliability measured.
- Cost caps active.
- Escalation tested.
- Monitoring assigned.
- Founder approves the scope.

No general “all agents autonomous” switch is required or recommended.

---

## 19. Traceability

| Technical area | PRD references |
|---|---|
| Context/model handling | PRD-025, PRD-030 |
| Approvals | PRD-015, PRD-018, PRD-026 |
| Duplicate protection | PRD-028 |
| Stop/recovery | PRD-027, PRD-029, PRD-030 |
| Client isolation | PRD-010, PRD-026 |
| Finance integration | PRD-016–019 |
| Records and artifacts | PRD-004–014 |
| Support/recurring work | PRD-020–024 |

---

## 20. Acceptance criteria

- [ ] Logical components have clear responsibilities.
- [ ] Tool capabilities are verified before dependency.
- [ ] Canonical record ownership is assigned.
- [ ] Production actions are validated and authorized.
- [ ] Duplicate and uncertain-outcome handling exists.
- [ ] Client isolation is enforced.
- [ ] Secrets are excluded from general context.
- [ ] Failures produce recoverable records.
- [ ] Hardware limits are measured.
- [ ] Deployment depends on evidence, not generated configuration.

### Current state

**TRD drafted. Architecture remains proposed. No infrastructure, integration, concurrency control or security mechanism has been implemented or tested through this document.**

### Change history

| Version | Change |
|---|---|
| 0.1.0 | Initial technical architecture and requirements |

---
