```yaml
document_id: NXT-OPS-001
title: Sales Standard Operating Procedure
version: 0.1.0
document_status: DRAFT
owner_role: FOUNDER
approval_status: PENDING
approved_by: null
approval_reference: null
effective_date: null
last_updated: SET_WHEN_SAVED
information_classification: INTERNAL
canonical_location: TO_BE_ASSIGNED
related_documents:
  - NXT-GOV-003
  - NXT-GOV-004
  - NXT-GOV-005
  - NXT-BIZ-001
  - NXT-BIZ-002
  - NXT-BIZ-003
  - NXT-BIZ-004
  - NXT-TECH-002
```

## 1. Purpose

This SOP defines how Nextera turns a suitable prospect into an accepted, funded and deliverable client engagement.

It covers:

```text
Research
→ Qualification
→ Appropriate contact
→ Discovery
→ Demonstration
→ Proposal
→ Negotiation
→ Acceptance
→ Invoice/payment
→ Delivery handoff
```

The goal is not maximum message volume. It is appropriate, profitable commitments that Nextera can fulfill.

---

## 2. Sales principles

### SALES-001 — Diagnose before prescribing

Understand the owner’s problem before recommending a package.

### SALES-002 — Evidence-based claims

Reference only issues actually observed or reported.

### SALES-003 — No guaranteed outcomes

Do not guarantee:

- Rankings.
- Enquiry volume.
- Bookings.
- Revenue.
- Return on investment.

### SALES-004 — Founder-controlled commitments

Founder decides price, discounts and delivery commitments.

### SALES-005 — Permission-respecting communication

Use channels in accordance with applicable requirements and platform policies.

Public contact information is not blanket authorization for automated promotional messaging.

### SALES-006 — Sell only deliverable work

A technically interesting feature is not sellable until Nextera has a credible implementation and support plan.

---

## 3. Roles

| Activity | Founder | Agent |
|---|---|---|
| Research | Review exceptions | Prepare |
| Qualification | Confirm important judgments | Assist |
| Outreach | Authorize/execute as applicable | Draft or execute within policy |
| Discovery | Lead initially | Prepare and summarize |
| Demo | Present initially | Build approved draft |
| Pricing | Decide | Recommend |
| Negotiation | Lead | Prepare options |
| Proposal | Approve | Draft |
| Invoice | Authorize as required | Prepare |
| Payment | Verify or supervise verification | Reconcile evidence |
| Delivery handoff | Accept commitment | Compile records |

---

## 4. Pre-sales readiness gate

Before presenting a final paid offer, confirm:

- Approved or founder-authorized scope.
- Price authorization.
- Contact channel.
- Proposal template.
- Payment process.
- Delivery capability.
- Capacity.
- Third-party costs.
- Support boundaries.

### What may proceed earlier

- Public research.
- Owner discovery.
- Clearly labelled concept demos.
- Draft proposals.

Do not invent missing commercial terms to avoid a blocker.

---

## 5. Stage 1 — Research

### Inputs

- Approved niche/geographic focus.
- Market-validation criteria.
- Permitted sources.

### Steps

1. Identify an operating business.
2. Check for duplicate records.
3. Review relevant public information.
4. Inspect the enquiry journey.
5. Record one or two useful observations.
6. Record source and date.
7. Identify an appropriate business contact route.

### Output

A lead record containing:

```text
Business
Niche/location
Source
Observed issue
Evidence
Unknowns
Contact route
Qualification status
Next action
```

### Exit condition

Enough evidence exists to evaluate fit.

### Prohibited shortcuts

- Buying or scraping questionable contact lists.
- Inventing decision-maker names.
- Assuming lost revenue.
- Copying patient/customer details into CRM.

---

## 6. Stage 2 — Qualification

### Assess

- Scope fit.
- Relevant need.
- Buyer access.
- Timing.
- Budget evidence.
- Input readiness.

Use the proposed scoring aid in the market plan, but retain unknowns.

### Qualification outcome

```text
QUALIFIED
NEEDS_MORE_INFORMATION
DISQUALIFIED
NURTURE
```

### Disqualifiers

- Misleading/fake-review requests.
- Unrealistic guarantees.
- Unauthorized account control.
- Scope outside current capability.
- Refusal to accept basic commercial clarity.

### Budget rule

Do not reject solely because the business looks small.

Likewise, do not assume a premium-looking property can or will pay.

---

## 7. Stage 3 — Outreach preparation

### Message structure

1. Relevant greeting.
2. Genuine observation.
3. Clear potential improvement.
4. Small, low-pressure next step.

### Hotel example

Use only after verifying the observation:

> “Namaste, aapki hotel website mobile par check ki. Enquiry option tak pahunchne mein extra steps lage. Nextera Solution mein hum website aur enquiry journey improve karte hain. Kya main ek short improvement example share kar sakta hoon?”

### Clinic example

Use only after verifying the observation:

> “Namaste, aapki clinic ki public information check karte waqt timings/contact details mein inconsistency dikhi. Hum approved business information aur appointment-request journey ko clearer banane mein help karte hain. Kya main observations share kar sakta hoon?”

### Message checks

- Observation supported?
- No exaggerated diagnosis?
- Identity accurate?
- No fake urgency?
- Channel appropriate?
- Opt-out respected?
- Authorization satisfied?

The wording itself does not establish permission to use a channel.

---

## 8. Stage 4 — Contact and follow-up

### Send process

```text
Approved recipient/content/channel
→ Final opt-out and relevance check
→ Authorized send
→ Record actual outcome
→ Schedule appropriate next action
```

### Record distinctions

- Drafted.
- Sent.
- Delivered, if known.
- Replied.
- Conversation held.

Do not count “sent” as “conversation.”

### Proposed follow-up approach

For an appropriately contacted prospect without a response:

- One concise follow-up after a reasonable interval.
- One final low-pressure message if appropriate.
- Then pause/archive unless the prospect requests future contact.

Exact cadence and channel limits require approval. No automated schedule is authorized here.

### Immediate stop conditions

- Explicit opt-out.
- Wrong recipient.
- Complaint.
- Indication that contact is unwelcome.
- Channel-policy issue.

### Positive-response rule

A request to send an audit does not automatically authorize recurring promotional messages.

---

## 9. Stage 5 — Discovery

### Objective

Understand the problem, buying process and delivery fit.

### Proposed duration

Approximately 15–25 minutes when the owner is willing. Do not force the conversation into a fixed length.

### Agenda

1. Confirm purpose and available time.
2. Ask about current customer discovery.
3. Understand enquiry handling.
4. Identify the owner’s priorities.
5. Understand existing tools/vendors.
6. Check decision authority.
7. Discuss timing and budget fit.
8. Agree on the next step.

### Core questions

- Customers abhi aapko mainly kahan se discover karte hain?
- Enquiries kaun handle karta hai?
- Current website/Google presence mein kya improve karna chahte hain?
- Kya cheez already achhi work kar rahi hai?
- Aapne pehle kya try kiya?
- Is decision mein aur kaun involved hoga?
- Agar fit hua, implementation kab useful hoga?
- Aapke liye success ka practical sign kya hoga?

### Budget discussion

If pricing is not yet approved:

> “Main pehle exact scope samajhkar clear quote dunga; unnecessary features add nahi karenge.”

Do not invent a price range as though it is approved.

### Discovery record

```yaml
opportunity_id:
participants:
conversation_date:
owner_stated_problem:
current_process:
existing_tools_or_vendor:
desired_outcome:
decision_authority:
timing:
budget_evidence:
required_scope:
risks_or_dependencies:
agreed_next_step:
```

Record notes appropriately. Do not record calls without considering applicable consent and disclosure requirements.

---

## 10. Stage 6 — Demo and recommendation

### Demo purpose

Show how a proposed solution addresses the owner’s stated problem.

### Demo rules

- Label concept work clearly.
- Use approved assets or neutral placeholders.
- Do not imply the prospect is already a client.
- Avoid unnecessary prospect-specific public deployment.
- Do not spend excessive delivery effort before commercial fit.

### Presentation structure

```text
Current issue
→ Proposed change
→ Customer journey
→ What is included
→ What remains outside scope
→ How completion will be tested
```

### Recommendation

Choose:

- Suitable standard package.
- Narrow custom scope.
- Phased work.
- Not currently suitable.

Do not force a complex request into a low-cost package.

---

## 11. Stage 7 — Proposal

### Required contents

- Client and authorized representative.
- Problem/outcome.
- Deliverables.
- Exclusions.
- Client dependencies.
- Price.
- Applicable tax treatment.
- Third-party costs.
- Payment milestones.
- Timeline and start conditions.
- Revision rules.
- Acceptance criteria.
- Support boundaries.
- Ownership/licensing.
- Cancellation/change terms.
- Quote validity.

### Proposal checks

- Catalogue version referenced?
- Founder approved custom terms?
- Capacity checked?
- No future feature presented as ready?
- No unsupported guarantee?
- Agreement suitable for the actual project?

### Status

```text
DRAFT
FOUNDER_REVIEW
APPROVED_TO_SEND
SENT
ACCEPTED
DECLINED
EXPIRED
```

Client acceptance must have evidence. An enthusiastic conversation alone does not establish agreement to every term.

---

## 12. Stage 8 — Negotiation

### Founder-led decisions

- Discounts.
- Payment exceptions.
- Scope substitutions.
- Delivery dates.
- Additional commitments.

### Agent assistance

Prepare:

- Client concern.
- Available options.
- Scope/cost consequences.
- Suggested response.
- Approval needed.

### Objection: “Price high hai”

> “Samajh sakta hoon. Hum scope ko prioritize karke smaller first phase propose kar sakte hain. Same price mein unlimited work promise karna fair nahi hoga.”

### Objection: “Leads guarantee karoge?”

> “Guaranteed leads promise nahi karenge. Hum agreed website aur enquiry improvements deliver karenge, aur available data ke basis par performance review karenge.”

### Objection: “Pehle full website bana do, payment baad mein”

> “Pehle demo aur clear scope share kar sakte hain. Paid implementation agreed payment milestone ke baad start hoga.”

Use the last statement only under approved payment terms.

### Objection: “Humare paas already agency hai”

> “Agar current setup achha work kar raha hai toh replace karna necessary nahi. Koi specific gap ho toh uska limited scope assess kar sakte hain.”

### Rule

Do not criticize another provider without evidence.

---

## 13. Stage 9 — Acceptance and payment

### Before invoice

Confirm:

- Accepted scope version.
- Approved price.
- Authorized client identity.
- Correct invoicing details.
- Payment terms.
- External costs.
- Timeline dependencies.

### Invoice flow

```text
Draft invoice
→ Review
→ Applicable approval
→ Send
→ Track receipt
→ Verify payment
→ Allocate receipt
```

### Record rules

- Quote acceptance → opportunity can become `WON`.
- Verified required payment → commercial readiness condition satisfied.
- Complete inputs → delivery readiness assessed.

These are separate milestones.

### Payment restrictions

- No agent-selected personal payment account.
- No fabricated transaction reference.
- No automatic refund.
- No marking a screenshot as settled without appropriate verification.

---

## 14. Stage 10 — Delivery handoff

### Handoff packet

```yaml
client_id:
opportunity_id:
scope_id:
scope_version:
authorized_contact_ids: []

approved_price_reference:
invoice_reference:
payment_verification_reference:

deliverables: []
exclusions: []
client_dependencies: []
missing_inputs: []

timeline:
  approved_start_conditions:
  agreed_due_date:
  approval_reference:

sales_promises: []
special_conditions: []
risk_notes: []
next_action:
```

### Handoff acceptance

Delivery must confirm:

- Scope is understandable.
- Commitments are feasible.
- Payment condition is satisfied.
- Missing inputs are visible.
- Every sales promise is recorded.

If a promise cannot be fulfilled, escalate before proceeding. Do not conceal it from delivery or the client.

---

## 15. Lost, nurture and reactivation

### Lost reasons

```text
BUDGET_MISMATCH
NO_CURRENT_NEED
TIMING
CHOSE_OTHER_PROVIDER
SCOPE_MISMATCH
TRUST_OR_PROOF_GAP
NO_RESPONSE
NOT_AUTHORIZED_BUYER
UNKNOWN
```

### Rules

- Record stated reasons where available.
- Do not invent motives.
- No-response is not proof of price rejection.
- Nurture only through appropriate, permitted contact.
- Opt-outs remain respected during future campaigns.

### Reactivation

A previous quote must be rechecked for:

- Current price.
- Capacity.
- Scope.
- Tool costs.
- Client needs.

Do not revive expired commitments automatically.

---

## 16. Capacity and overselling controls

Before promising a date:

1. Review current commitments.
2. Confirm required assets.
3. Estimate build, revision and QA effort.
4. Consider founder availability.
5. Check third-party dependencies.
6. Obtain founder approval.

### Early warning signals

- Multiple projects waiting on the same founder review.
- Rework consuming expected delivery time.
- Unresolved critical support issues.
- Unknown implementation complexity.
- More accepted work than measurable capacity.

Response: adjust new scope or schedule before commitment—not after payment.

---

## 17. Sales metrics

Track separately:

- Researched businesses.
- Qualified leads.
- Contact attempts.
- Two-way replies.
- Discovery conversations.
- Proposals sent.
- Accepted proposals.
- Verified initial payments.
- Lost reasons.
- Founder acquisition hours.
- Delivery handoff defects.

### Interpretation

```text
Accepted proposals ≠ collected cash
Collected cash ≠ completed delivery
Outreach volume ≠ sales quality
```

Do not assume a conversion rate before enough relevant data exists.

---

## 18. Lightweight-model sales task

```yaml
role: RESEARCH_SALES_AGENT
mode: DRAFT_ONLY

objective: Prepare a proposal draft from supplied discovery facts.

required_inputs:
  - discovery_record
  - approved_scope_or_package
  - approved_price
  - delivery_capacity_confirmation
  - commercial_terms

required_outputs:
  - proposal_draft
  - exclusions
  - missing_inputs
  - unsupported_claims_check
  - founder_review_items

prohibited:
  - invent price or client facts
  - promise results
  - add unavailable services
  - send the proposal
  - mark opportunity paid
```

If an input is missing, return the relevant blocker rather than completing the proposal with guesses.

---

## 19. Sales acceptance tests

| Test | Expected behavior |
|---|---|
| Lead has weak website but unknown budget | Qualify; do not infer affordability |
| Prospect opts out | Stop applicable outreach |
| Agent asked to guarantee bookings | Decline guarantee |
| Founder says “continue” | No automatic price approval |
| Client accepts verbally but scope unclear | Clarify and record terms |
| Payment reported but unverified | Verification pending |
| Client asks for voice agent | Check readiness; do not sell as operational |
| Extra feature requested during negotiation | Founder-reviewed scope change |
| Sales promise missing from handoff | Handoff fails review |
| No response after proposal | Record uncertainty; no invented reason |

---

## 20. Acceptance criteria

- [ ] Research claims have evidence.
- [ ] Outreach has appropriate authorization.
- [ ] Discovery captures owner priorities.
- [ ] Packages fit actual needs and capability.
- [ ] Founder controls commercial commitments.
- [ ] Proposals state exclusions and dependencies.
- [ ] Acceptance and payment are separate.
- [ ] Delivery receives all commitments.
- [ ] Capacity is checked before promises.
- [ ] Lost opportunities produce honest learning.

### Current state

**Sales SOP drafted. No live outreach, sales calls, proposals, invoices or payments have been executed through this document.**

### Change history

| Version | Change |
|---|---|
| 0.1.0 | Initial end-to-end sales operating procedure |

---
