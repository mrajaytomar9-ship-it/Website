```yaml
document_id: NXT-SEC-001
title: Security, Privacy and Compliance Baseline
version: 0.1.0
document_status: DRAFT
owner_role: FOUNDER
approval_status: PENDING
approved_by: null
approval_reference: null
effective_date: null
last_updated: SET_WHEN_SAVED
information_classification: INTERNAL
canonical_location: TO_BE_ASSIGNED
related_documents:
  - NXT-GOV-000
  - NXT-GOV-003
  - NXT-GOV-005
  - NXT-BIZ-001
  - NXT-TECH-001
  - NXT-TECH-002
  - NXT-OPS-003
  - NXT-OPS-004
```

## 1. Purpose

This document establishes minimum controls for protecting:

- Nextera accounts.
- Founder information.
- Client credentials.
- Client business records.
- Enquiry data.
- Financial records.
- Website source and production systems.

It also defines a process for identifying applicable legal, contractual and platform obligations.

This document is not:

- A legal opinion.
- A compliance certification.
- A guarantee of security.
- A substitute for professional advice where required.

---

## 2. Security objectives

### SEC-001 — Confidentiality

Information is available only to authorized parties.

### SEC-002 — Integrity

Records, approvals and deliverables cannot be silently altered without traceability.

### SEC-003 — Availability

Services and records have recovery arrangements appropriate to their commitments.

### SEC-004 — Accountability

Material actions can be attributed to an authorized actor.

### SEC-005 — Data minimization

Collect, store and transmit only what is necessary for the agreed purpose.

### SEC-006 — Privacy-aware defaults

Do not collect sensitive data merely because a tool supports it.

---

## 3. Threat model

Initial risks include:

- Compromised founder laptop.
- Phishing or credential theft.
- Secrets pasted into AI chats.
- Malicious instructions inside external content.
- Wrong-client data retrieval.
- Unauthorized agent actions.
- Public staging exposure.
- Insecure dependencies.
- Accidental deletion.
- Lost backups.
- Unreviewed AI-provider data handling.
- Incorrect recipient in an email/message.
- Shared account access that cannot be revoked cleanly.

Controls should address realistic risks rather than create a complex security theatre.

---

## 4. Data inventory and roles

Before handling production data, record:

```yaml
processing_activity_id:
purpose:
client_or_company_owner:
data_categories: []
data_subject_categories: []
source:
systems_used: []
authorized_users: []
external_providers: []
storage_locations:
retention_policy_reference:
legal_or_contractual_basis_review:
security_controls: []
```

### Role assessment

Nextera may handle data:

- For its own business purposes, such as prospecting and invoicing.
- On a client’s instructions, such as managing enquiry routing.
- Through providers with their own terms and responsibilities.

The applicable legal role must be assessed per activity. Calling Nextera an “agency” does not automatically settle those obligations.

---

## 5. Classification and handling

| Classification | Examples | Minimum handling |
|---|---|---|
| PUBLIC | Approved website copy | Publish only through authorized process |
| INTERNAL | General SOPs | Authorized workforce access |
| CONFIDENTIAL | Contracts, leads, finance, client records | Need-to-know access and controlled sharing |
| RESTRICTED | Credentials, sensitive personal data | Approved secure storage and tightly limited access |

### Rules

- Classification follows the most sensitive meaningful content.
- A publicly accessible email address can still be personal data.
- Anonymized data must not be called anonymous if individuals remain reasonably identifiable.
- Redacting names alone may not remove re-identification risk.

---

## 6. Device security

### Founder workstation baseline

Before sensitive production access:

- Verify current OS support and updates.
- Keep browser and essential software updated.
- Use device login protection.
- Enable suitable device encryption where available and properly configured.
- Use screen locking.
- Maintain reputable endpoint protection.
- Avoid untrusted software and extensions.
- Use a non-administrator account for routine work where practical.
- Protect recovery information.
- Maintain tested backups.

### Capability boundary

The supplied laptop specifications do not establish that these controls are enabled.

Record actual inspection results.

### Lost-device response

- Notify the founder/security owner immediately.
- Revoke relevant sessions and credentials through authorized processes.
- Assess stored data and encryption.
- Review client impact.
- Document recovery.

Do not assume remote wipe is available.

---

## 7. Identity and account access

### Required practices

- Prefer named accounts.
- Use MFA where supported.
- Avoid shared passwords when delegation exists.
- Separate client accounts.
- Grant minimum necessary permissions.
- Review stale access.
- Revoke access at offboarding.
- Keep recovery methods under appropriate ownership.

### Client ownership

Do not replace a client’s recovery email or primary ownership merely for convenience.

### Access review triggers

- New client.
- New contractor.
- Role change.
- Suspected compromise.
- Project completion.
- Service termination.
- Tool replacement.

### Access register

Reference the canonical access records rather than creating unmanaged copies.

---

## 8. Secrets management

### Secrets include

- Passwords.
- API keys.
- Access tokens.
- Refresh tokens.
- Recovery codes.
- Private keys.
- Signing secrets.

### Rules

- Store secrets in an approved password manager or secret store.
- Do not place them in Notion task fields.
- Do not embed them in prompts.
- Do not commit them to source control.
- Do not expose them in client-side website code.
- Redact them from logs and screenshots.
- Use scoped credentials where possible.

### Exposure response

If a secret is exposed:

1. Stop unnecessary further distribution.
2. Identify affected systems.
3. Revoke/rotate through authorized procedures.
4. Assess misuse.
5. Update dependent systems safely.
6. Preserve incident evidence without replicating the secret.

Deleting a message or file does not prove the credential is safe again.

---

## 9. AI-provider and model review

Before sending confidential data, assess:

- Provider identity.
- Model endpoint.
- Terms and permitted use.
- Data retention.
- Training/use of submitted data.
- Logging.
- Subprocessors or routing.
- Storage/processing locations where relevant.
- Security documentation.
- Account controls.
- Deletion options.
- Contractual suitability.

### Routing services

A routing provider may involve more than one downstream model provider.

Review the actual route and its handling where relevant. Do not assume every model on one platform has identical privacy behavior.

### Local models

Local execution can reduce some external transmission, but does not automatically ensure privacy.

Check:

- Telemetry.
- Extensions.
- Model/runtime supply chain.
- Local file access.
- Logs.
- Other connected tools.

### License review

Open-weight availability does not automatically permit every commercial use.

Review the actual model and dependency licenses.

---

## 10. Client-data isolation

### Required controls

- Client-specific record IDs.
- Scoped retrieval.
- Separate file locations or equivalent permission boundaries.
- Explicit project context.
- Validation before external sends.
- No unrelated client examples in live task packets.

### Cross-client reporting

Use aggregated or minimized data only under appropriate authorization.

Do not give an agent unrestricted client-database access merely to create a general report.

### Test

A task for Client A must fail validation if it references Client B’s contact, scope or production target without explicit authorization.

---

## 11. Secure development and tools

### Baseline

- Use known, maintained dependencies where practical.
- Review licenses.
- Limit unnecessary packages.
- Pin or record versions appropriately.
- Review generated code before execution.
- Keep secrets out of repositories.
- Test outside production.
- Use protected/private repositories for confidential work.
- Preserve recoverable versions.

### Installation rule

AI-generated terminal commands are proposals, not inherently safe instructions.

Before running commands that install, delete, change permissions or alter production:

- Understand the effect.
- Check source and scope.
- Confirm authorization.
- Prepare recovery where appropriate.

### Untrusted files

Do not execute attachments, scripts or macros merely because a client sent them.

Inspect through a suitable safe process.

---

## 12. Website and form privacy

### Minimum-data design

Collect only information required for the enquiry workflow.

Avoid:

- Unnecessary date of birth.
- Identity-document uploads.
- Detailed health questions.
- Payment-card information in ordinary forms.
- Sensitive information in query strings or analytics events.

### Privacy notice

Where personal data is collected, provide a clear notice suitable to the actual activity.

It should accurately describe relevant matters such as:

- Who handles the information.
- Purpose.
- What is collected.
- Recipients/providers where applicable.
- Contact route.
- Rights and retention information as required.

Do not copy a generic notice that describes systems Nextera does not use.

### Consent and tracking

Determine applicable consent/notice requirements before enabling analytics, remarketing or other tracking.

Do not install a decorative cookie banner while scripts ignore its settings.

Do not assume every site needs the same consent mechanism.

---

## 13. Healthcare-specific baseline

Initial clinic services should remain administrative.

### Avoid by default

- Patient records.
- Diagnostic reports.
- Prescription information.
- Symptom histories.
- Insurance details.
- Automated clinical recommendations.

### Appointment enquiries

Keep fields minimal and clarify that submission is a request unless confirmed through an authorized process.

### Public communication

Do not disclose patient relationships or health details in:

- Review replies.
- Social content.
- Case studies.
- Agent prompts.
- Support screenshots.

### Expansion gate

Any future healthcare-data workflow requires a separate privacy, legal, security and clinical-boundary assessment.

A clinic owner’s request alone does not establish that Nextera’s current system is suitable.

---

## 14. Commercial communication and outreach

Before scaled messaging/calling, review:

- Applicable Indian commercial-communication requirements.
- Channel-specific platform policies.
- Contact-source restrictions.
- Consent or other applicable permissions.
- Opt-out handling.
- Caller/message identification.
- Approved integration methods.

Depending on the channel, relevant obligations may involve telecom rules and provider registration/template processes. Verify current applicability rather than assuming one rule covers all channels.

### Prohibited practices

- Bypassing rate limits with multiple accounts.
- Using unofficial integrations to evade restrictions.
- Ignoring opt-outs.
- Misrepresenting identity.
- Sending sensitive information to unverified recipients.
- Treating a public phone number as unrestricted promotional permission.

---

## 15. Legal and compliance verification register

Before relevant operations, maintain:

```yaml
obligation_id:
topic:
business_activity:
jurisdiction:
source_authority:
official_source_reference:
last_checked:
applicability_status:
effective_date_review:
required_action:
owner:
professional_review_needed:
evidence_reference:
next_review_trigger:
```

### Topics to assess

- Business structure and identity.
- Invoicing and applicable taxes.
- Client contract terms.
- Data protection and privacy.
- Commercial communications.
- Consumer/business advertising claims.
- Intellectual property and asset licensing.
- Sector-specific healthcare advertising or content restrictions.
- Platform terms.
- Record retention.
- Security-incident notification obligations.

### India-specific caution

Where relevant, review India’s data-protection framework, including the Digital Personal Data Protection Act, 2023 and applicable notified rules, commencement provisions and exemptions.

Do not assume every provision is applicable to Nextera on the same date or in the same manner. Confirm current official requirements before operational reliance.

This document has not performed that legal verification.

---

## 16. Retention and deletion

### Retention schedule

Define per category:

```yaml
data_category:
purpose:
retention_trigger:
retention_period_or_rule:
legal_or_contractual_constraint:
backup_treatment:
deletion_method:
approval_requirement:
```

### Principles

- Do not retain data indefinitely “just in case.”
- Do not invent a universal retention duration.
- Keep financial/legal records where required.
- Respect valid client/data-subject requests through the appropriate process.
- Account for provider copies and backups.
- Record deletion limitations honestly.

### Deletion authority

Founder authorization remains required for destructive actions.

Automated retention deletion requires a specifically approved policy and tested controls.

---

## 17. Data requests

Requests may concern:

- Access.
- Correction.
- Export.
- Deletion.
- Withdrawal of permission.
- Restriction of use, where applicable.
- Client offboarding.

### Workflow

1. Record the request.
2. Verify identity proportionately.
3. Determine authority and relevant obligations.
4. Identify affected systems.
5. Review exceptions or required retention.
6. Obtain applicable authorization.
7. Execute.
8. Verify.
9. Respond accurately.

Do not collect more identity information than reasonably necessary to verify the request.

Do not disclose data to an unverified requester.

---

## 18. Backup and recovery security

### Requirements

- Backups must be access-controlled.
- Sensitive backups require appropriate protection.
- Recovery credentials must be protected.
- Restore tests must be recorded.
- Backups must not become unrestricted copies of all client data.
- Retention and offboarding rules must consider backups.

### Recovery checks

- Correct client.
- Correct version.
- New-data preservation.
- Access permissions after restore.
- Functionality.
- Secret exposure.
- Record integrity.

A successful file copy is not proof of usable recovery.

---

## 19. Security incidents and notification

Use `NXT-OPS-004` for operational handling.

Security review must determine:

- What happened.
- What data/accounts were affected.
- Whether access or disclosure occurred.
- Who may be affected.
- Which contractual, legal or platform notification duties apply.
- What deadlines apply to that situation.

### Rule

Do not hard-code a universal breach-notification deadline without establishing the applicable obligation.

Do not delay necessary escalation while waiting for perfect certainty.

### Communication

Separate:

```text
Confirmed facts
Reasonable suspicions
Unknowns
Actions completed
Actions planned
```

Regulatory/client notifications require the appropriate authorized review, but this must not become a reason to ignore applicable deadlines.

---

## 20. Provider and contractor onboarding

Before access:

- Define task and scope.
- Review necessary data.
- Verify identity and account.
- Establish confidentiality/data-handling terms where appropriate.
- Grant least privilege.
- Set review/end date.
- Explain incident reporting.
- Document revocation.

### Offboarding

- Revoke access.
- Rotate shared credentials if needed.
- Recover agreed assets.
- Confirm data handling.
- Preserve relevant records.

Hiring someone does not justify exposing the entire company workspace.

---

## 21. Security exceptions

If a required control cannot be implemented:

```yaml
exception_id:
control:
reason:
affected_data_or_system:
risk:
temporary_compensating_controls:
expiry:
owner:
founder_approval_reference:
```

### Limits

An internal exception cannot override legal obligations or third-party rights.

Do not normalize temporary exceptions into permanent practice without review.

If risk is unacceptable, pause the affected service.

---

## 22. Lightweight-model security contract

```yaml
role: SECURITY_REVIEW_ASSISTANT
mode: DRAFT_ONLY

objective: Review supplied configuration or workflow for defined risks.

required_outputs:
  - observed_risks
  - supporting_evidence
  - uncertainty
  - proposed_controls
  - actions_requiring_authorization
  - professional_review_questions

prohibited:
  - claim legal certification
  - invent provider policies
  - expose credentials
  - execute destructive containment
  - assume a secret is safe after deletion
  - certify absence of all vulnerabilities
```

Agents may help identify issues but must not market an automated review as a professional audit unless the service and qualifications support that claim.

---

## 23. Acceptance tests

| Test | Expected result |
|---|---|
| API key pasted into project notes | Flag exposure and initiate authorized credential response |
| Client A data enters Client B prompt | Block and investigate |
| Free model selected for patient data | Do not transmit without suitability/authorization |
| Generic privacy policy names unused tools | Correct before publication |
| Opted-out lead reappears | Applicable outreach remains suppressed |
| Client requests all records deleted | Review scope, authority and retention obligations |
| Unverified caller requests access | No disclosure/access grant |
| Model says a package is secure | Treat as claim requiring evidence |
| Backup restore could lose new enquiries | Assess preservation before action |
| Legal rule is outdated/uncertain | Verify current official applicability |

---

## 24. Acceptance criteria

- [ ] Data inventory and purposes are recorded.
- [ ] Sensitive access is minimized.
- [ ] Secrets remain outside general context.
- [ ] Devices and accounts are reviewed.
- [ ] AI providers are assessed for actual data use.
- [ ] Client isolation is tested.
- [ ] Forms and tracking match privacy requirements.
- [ ] Healthcare scope avoids unnecessary sensitive data.
- [ ] Legal obligations are verified through current sources.
- [ ] Retention, incidents and requests have controlled workflows.

### Current state

**Security/privacy baseline drafted. No device audit, legal review, provider assessment, access-control implementation or security certification has been performed through this document.**

### Change history

| Version | Change |
|---|---|
| 0.1.0 | Initial security, privacy and compliance baseline |

---
